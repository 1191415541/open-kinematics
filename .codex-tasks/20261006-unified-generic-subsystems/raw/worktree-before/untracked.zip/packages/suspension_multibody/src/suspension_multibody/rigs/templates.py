"""Ordinary authoring documents for the registered test benches."""

from __future__ import annotations

from typing import Any, Mapping

from ..authoring.documents import RigDocument, SubsystemDocument, TemplateDocument
from ..templates.builtin import WHEEL_HUB_MASS
from .rig import RigSpec, get_rig


def rig_template_document(rig: str | RigSpec) -> TemplateDocument:
    """Return a bench's physical declarations, without creating a runtime entity."""
    spec = get_rig(rig) if isinstance(rig, str) else rig
    bodies = [{"name": "bench_frame", "fixed": True}]
    points = [{"name": "mount", "owner": "bench_frame", "label": "mount"}]
    ports: list[dict[str, Any]] = []
    if spec.supplies_wheels:
        for side in ("L", "R"):
            owner = f"wheel_carrier_{side}"
            bodies.append({"name": owner, "mass": WHEEL_HUB_MASS})
            points.extend({"name": f"{label}_{side}", "owner": owner, "label": label}
                          for label in ("center", "contact"))
            ports.append({"name": f"wheel_centre_{side}", "owner": owner,
                          "point": f"center_{side}", "role": "wheel_centre",
                          "capabilities": ["wheel", "load"], "labels": [side]})
    else:
        ports.append({"name": "mount", "owner": "bench_frame", "point": "mount",
                      "role": "body_mount", "capabilities": ["load"]})
    return TemplateDocument.from_payload({
        "document": "template", "schema_version": 1, "name": "bench",
        "functional_role": "generic", "allowed_placement_roles": ["any"],
        "description": spec.description, "units": {"length": "m"},
        "symmetry": "asymmetric", "sides": ["left", "right"],
        "bodies": bodies, "hardpoints": points, "joints": [], "elements": [],
        "property_slots": [], "ports": ports,
        "outputs": [{"name": name, "unit": "1", "source": "rig"} for name in spec.outputs],
    })


def rig_subsystem_document(
    rig: str | RigSpec, *, hardpoints: Mapping[str, Any] | None = None,
) -> SubsystemDocument:
    """Bind bench geometry; the zero layout is resolved at its assembly ports."""
    spec = get_rig(rig) if isinstance(rig, str) else rig
    template = rig_template_document(spec)
    coordinates = {name: [0.0, 0.0, 0.0] for name in template.hardpoint_names}
    coordinates.update(hardpoints or {})
    return SubsystemDocument.from_payload({
        "document": "subsystem", "schema_version": 1, "name": spec.name,
        "template": template.name, "functional_role": "generic", "placement_role": "any",
        "hardpoints": coordinates, "property_bindings": {},
    }, template=template)


def rig_document(rig: str | RigSpec) -> RigDocument:
    """Return the bench's case interface separately from its physical template."""
    spec = get_rig(rig) if isinstance(rig, str) else rig
    return RigDocument.from_payload({
        "document": "rig", "schema_version": 1, "name": spec.name, "bench": spec.name,
        "supported_assembly_kinds": ["suspension_axle" if spec.supplies_wheels else "full_vehicle"],
        "required_ports": [], "actuators": list(spec.coordinate_names()),
        "measurements": list(spec.outputs),
    })


def rig_attachment_rows(rig: str | RigSpec) -> tuple[dict[str, str], ...]:
    """Declare the external joints used to bind bench ports to assembly ports."""
    template = rig_template_document(rig)
    return tuple({"name": f"{port['owner']}_weld", "type": "fixed",
                  "port": port["name"], "point": "center"}
                 for port in template.payload["ports"] if port["role"] == "wheel_centre")
