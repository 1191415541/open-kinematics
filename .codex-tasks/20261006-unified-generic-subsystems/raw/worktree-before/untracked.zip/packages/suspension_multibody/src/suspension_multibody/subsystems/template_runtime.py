"""Resolve declared points, modes and physical connections for any template."""

from __future__ import annotations

from collections.abc import Iterable

import numpy as np

from ..modeling.primitives.spatial import SE3
from ..templates.model import ConnectionDefinition
from .types import Connection, ResolvedElement, Side, SubsystemContext, SubsystemOutput


def bodies_from_data(rows: Iterable[dict]) -> dict:
    """Materialise bodies in declaration order."""
    from ..authoring.generic import GenericSubsystemAssembler

    return GenericSubsystemAssembler.materialize_bodies(rows)


def connection_content(
    declarations: Iterable[ConnectionDefinition],
    context: SubsystemContext,
    side: Side,
) -> SubsystemOutput:
    """Interpret point/connection data; external fallback choices are explicit."""
    rows = tuple(declarations)
    from ..authoring.generic import GenericSubsystemAssembler
    output = SubsystemOutput()
    for row in rows:
        if row.owner not in context.bodies:
            continue
        if row.record_owner_point:
            output.points[(row.owner, row.label or row.name)] = context.local(
                row.owner, context.point(side, row.role)
            )
    for row in rows:
        if row.owner not in context.bodies or not row.far_owner:
            continue
        far = next(
            (name for name in (row.far_owner, *row.far_fallbacks) if name in context.bodies),
            None,
        )
        if far is None and "ground" in row.far_fallbacks:
            far = "ground"
            context.bodies.update(bodies_from_data([{"name": far, "fixed": True}]))
        if far is None:
            raise ValueError(f"connection {row.name!r}: external attachment {row.far_owner!r} is unavailable")
        world = context.point(side, row.role)
        owner_point = context.local(row.owner, world)
        far_point = context.local(far, world)
        if row.record_far_point or far != row.far_owner:
            output.points[(far, row.far_label)] = far_point.copy()
        ends = ((row.owner, owner_point, row.label or row.name), (far, far_point, row.far_label))
        a, b = ends if row.first_body == "owner" else ends[::-1]
        column = row.active_column(context.mode)
        kind = row.joint_kind(context.mode) if column == "joint" else row.ideal_joint
        if kind is not None and column is not None:
            joint = {
                "name": row.name, "type": kind,
                "body_a": a[0], "point_a": a[1],
                "body_b": b[0], "point_b": b[1],
            }
            if kind not in {"spherical", "fixed", "revolute", "prismatic", "universal", "cylindrical"}:
                raise ValueError(f"unsupported ideal joint kind {kind!r}")
            if kind not in {"spherical", "fixed"}:
                axis = row.axis
                if row.axis_reference_role:
                    axis = context.point(side, row.axis_reference_role) - world
                if axis is None:
                    raise ValueError(f"connection {row.name!r}: joint {kind!r} needs an axis")
                values = np.asarray(axis, dtype=float)
                norm = np.linalg.norm(values)
                if norm <= 1e-12:
                    raise ValueError(f"connection {row.name!r}: axis hardpoints must be distinct")
                values = values / norm
                joint["axis_a"] = context.bodies[a[0]].pose.rotation.T @ values
                joint["axis_b"] = context.bodies[b[0]].pose.rotation.T @ values
            constraint = GenericSubsystemAssembler.materialize_joint(joint)
            output.ideal_constraints.append(constraint)
            if column == "joint":
                output.constraints.append(constraint)
        if column == "bushing":
            output.bushings.append(ResolvedElement(
                kind="bushing", name=row.bushing or row.name,
                spec=context.mount_bushing_stiffness,
                body_a=a[0], body_b=b[0],
                local_pose_a=SE3(a[1], np.array([1.0, 0.0, 0.0, 0.0])),
                local_pose_b=SE3(b[1], np.array([1.0, 0.0, 0.0, 0.0])),
            ))
        if row.record_connection:
            output.connections.append(Connection(
                row.name, "bushing" if column == "bushing" else "ideal",
                a[0], b[0], a[2], b[2],
            ))
    return output
