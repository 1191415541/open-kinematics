"""
Reading a case document back into the object its family prepares from.

A family's case document is written by its emitter (``cases/<family>.py``).  The
inverse -- document to the object the preparation takes -- lives here rather than
beside each emitter, because the two halves then share one spelling of the grid,
the solver block and the "which section is this family's" rule; splitting them
across modules is how a writer and a reader drift a field at a time.

Only the parts every dynamic family shares are here.  A family's own vocabulary
(its pads, its shapes, its speed) is read where that family's object is defined,
so a case this module cannot describe is a case no family asked for.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

__all__ = [
    "grid_times",
    "require_section",
    "solver_from_document",
]


def require_section(document: Mapping[str, Any], family: str, key: str) -> Mapping[str, Any]:
    """
    Return one family's section from a case document, or refuse by name.

    The refusal is the point: a document that carries no section for this family
    describes a run with nothing to solve, and saying which section was expected
    is what turns "KeyError: 'four_post'" into an instruction.
    """
    section = document.get(key)
    if section is None:
        raise ValueError(
            f"a {family!r} case document states its inputs in a {key!r} section; "
            "this one carries none"
        )
    if not isinstance(section, Mapping):
        raise TypeError(
            f"the {key!r} section must be an object, got {type(section).__name__}"
        )
    return section


def grid_times(document: Mapping[str, Any], *, key: str = "times_s") -> tuple[float, ...]:
    """
    Return the case's time grid as explicit samples.

    Two spellings are accepted because two are in use: a ``time`` block stating
    start/end/step (what the emitters write) and an explicit ``times_s`` list (what
    a caller with a measured grid has).  Both come back as samples, so a reader
    below never has to know which one the document used.
    """
    time = document.get("time")
    if not isinstance(time, Mapping):
        raise ValueError(
            "a case document states its grid as a 'time' block with "
            "start_s/end_s/step_s"
        )
    start = float(time["start_s"])
    end = float(time["end_s"])
    step = float(time["step_s"])
    if step <= 0.0:
        raise ValueError(f"time.step_s must be positive, got {step!r}")
    if end < start:
        raise ValueError(f"time.end_s {end!r} precedes time.start_s {start!r}")
    count = int(round((end - start) / step)) + 1
    return tuple(start + index * step for index in range(count))


def solver_from_document(document: Mapping[str, Any]) -> Any:
    """
    Return the solver settings a case document states, or the family default.

    Unknown keys are ignored rather than refused: the document is a declaration
    of what to run, and a setting this build does not know is a newer document
    read by an older build -- refusing it would make a forward-compatible field
    into a hard error.  A *known* key with a bad value is still refused, by the
    settings class itself.

    ``initialization_mode`` is the one field whose *default* cannot be the
    settings class's own.  Whether a run starts from a computed trim is what the
    case's ``static_equilibrium`` says, and that flag is read from the vehicle
    case by :func:`~.vehicle_case_document.vehicle_case_from_document` for every
    vehicle family.  Letting this reader fall back to ``AxleSolverSettings()``
    instead silently answered "trim it" to a bench that had asked for nothing of
    the sort -- the kernel was handed a static-equilibrium initialisation the
    caller never declared, on models whose state it provides, and every one of
    those runs stopped at ``static equilibrium initialization failed``.  A
    document that really wants a trim states it, either as this field or through
    ``static_equilibrium``; the two spellings now mean one thing.
    """
    from ..schema.solver import AxleSolverSettings

    declared = document.get("solver")
    known = set(AxleSolverSettings.model_fields)
    given = (
        {key: value for key, value in declared.items() if key in known}
        if isinstance(declared, Mapping)
        else {}
    )
    # The vehicle-level flag is the answer when the solver block does not state
    # the mode itself: a case that asks for a static equilibrium gets one, and one
    # that says nothing gets the state it provided.
    given.setdefault(
        "initialization_mode",
        "static_equilibrium" if _static_equilibrium_declared(document) else "provided_consistent_state",
    )
    return AxleSolverSettings(**given)


def _static_equilibrium_declared(document: Mapping[str, Any]) -> bool:
    """Return whether the case asks for a computed static equilibrium."""
    section = document.get("vehicle_dynamic")
    if not isinstance(section, Mapping):
        return False
    return bool(section.get("static_equilibrium", False))
