"""
Reading the vehicle-level case a document states.

Every vehicle family wraps one ``VehicleDynamicCase``: the family's own section
says what the *bench* adds (pads, shapes, a speed), and this says what the
*vehicle run* integrates.  Reading it in one place is what keeps five families
from each inventing a slightly different vehicle, and it is also where the
vehicle's own declaration is required -- a vehicle case without a vehicle is not
a run.

The declaration comes from the assembly document rather than from the case: which
chassis, which wheels and which steering a model has is a property of the model,
and a case that restated them would be a second description of one vehicle.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, cast

__all__ = ["vehicle_case_from_document"]

#: How an axle solver's integrator name reads in the vehicle schema.  The two
#: schemas name the same integration scheme differently -- the axle boundary uses
#: the kernel's own spelling, the vehicle case uses the study-level one -- and
#: that difference is a fact about the two vocabularies rather than a defect in
#: either.  A name with no mapping is refused by the vehicle settings class.
_INTEGRATORS = {"ggl_generalized_alpha": "generalized_alpha"}

#: The value the vehicle case's ``suspension_mode`` takes.
_MODES = ("auto", "K", "C")

#: The suspension mode literal the vehicle case declares.
SuspensionMode = Literal["auto", "K", "C"]

#: The travelling-direction sign literal the vehicle case declares.
VelocitySign = Literal[-1, 1]


def vehicle_case_from_document(
    document: Mapping[str, Any],
    *,
    times_s: tuple[float, ...],
    declaration: Any = None,
) -> Any:
    """
    Return the ``VehicleDynamicCase`` a case document states.

    ``declaration`` is the vehicle the run is on, when the caller already has it
    (the document route builds it from the assembly); when it is absent the case
    document's own ``vehicle`` block is read instead, which is the spelling a
    caller with a hand-authored case uses.
    """
    from ..schema.vehicle import VehicleDynamicCase

    if declaration is None:
        declaration = document.get("_declaration")
    if declaration is None:
        declaration = _declaration_from_document(document)
    section = document.get("vehicle_dynamic")
    section = section if isinstance(section, Mapping) else {}
    return VehicleDynamicCase(
        name=str(section.get("name") or document.get("name") or "full_vehicle_dynamic"),
        solver=_solver(document),
        vehicle=declaration,
        road=_road(document),
        steering_input=_signal(document, "steering_input"),
        brake_input=_signal(document, "brake_input"),
        drive_input=_signal(document, "drive_input"),
        wheel_drive_torque=_torque_pairs(document, "wheel_drive_torque"),
        wheel_brake_torque=_torque_pairs(document, "wheel_brake_torque"),
        initial_wheel_speeds=_wheel_speeds(document),
        initial_states=_initial_states(document),
        static_equilibrium=bool(section.get("static_equilibrium", False)),
        suspension_mode=cast(
            "SuspensionMode", _mode(section.get("suspension_mode"))
        ),
        initial_forward_speed_mps=float(section.get("initial_forward_speed_mps", 0.0)),
        initial_velocity_sign=cast("VelocitySign", _sign(section.get("initial_velocity_sign", 1))),
    )


def _declaration_from_document(document: Mapping[str, Any]) -> Any:
    """Return the vehicle declaration a document names, or refuse by name."""
    from ..schema.vehicle import VehicleDeclaration

    block = document.get("vehicle")
    if block is None:
        raise ValueError(
            "a vehicle case document states the vehicle it runs on as a "
            "'vehicle' block (or is given one by the assembly it belongs to); "
            "this one carries none"
        )
    return VehicleDeclaration.model_validate(block)


def _solver(document: Mapping[str, Any]) -> Any:
    """
    Return the dynamic solver settings a document states.

    ``DynamicSolverSettings`` requires the window it integrates (``end_time`` and
    ``step_size``), and a case document states that window once, in its ``time``
    block: the grid the run reports on and the window it integrates are the same
    numbers, so the solver block carries only what is *not* the window (the
    integrator, the tolerances).  Reading the window from ``time`` is what keeps a
    document from having to state it twice.
    """
    from ..schema.dynamic import DynamicSolverSettings

    declared = document.get("solver")
    if not isinstance(declared, Mapping):
        raise ValueError("a vehicle case document states a 'solver' block")
    known = set(DynamicSolverSettings.model_fields)
    given: dict[str, Any] = {
        key: value for key, value in declared.items() if key in known
    }
    # The window is the case's own, stated in the time block.  A solver block that
    # states it too would be a second description of one window, so the explicit
    # value wins only when the time block is absent (fixtures and hand-authored
    # cases spell it there).
    if "integrator" in given:
        given["integrator"] = _INTEGRATORS.get(
            str(given["integrator"]), given["integrator"]
        )
    time = document.get("time")
    if isinstance(time, Mapping):
        given.setdefault("end_time", float(time["end_s"]))
        given.setdefault("step_size", float(time["step_s"]))
    missing = sorted({"end_time", "step_size"} - set(given))
    if missing:
        raise ValueError(
            "a vehicle case document needs a 'time' block (or solver "
            f"end_time/step_size) so the run has a window; missing {missing}"
        )
    return DynamicSolverSettings(**given)


def _road(document: Mapping[str, Any]) -> Any:
    from ..schema.vehicle import RoadSurfaceSpec

    declared = document.get("road")
    if not isinstance(declared, Mapping):
        return RoadSurfaceSpec()
    return RoadSurfaceSpec.model_validate(declared)


def _signal(document: Mapping[str, Any], key: str) -> Any:
    from ..schema.dynamic import TimeSignal

    declared = document.get(key)
    if declared is None:
        return TimeSignal(constant=0.0)
    if not isinstance(declared, Mapping):
        raise TypeError(f"{key} must be an object, got {type(declared).__name__}")
    return TimeSignal.model_validate(declared)


def _torque_pairs(document: Mapping[str, Any], key: str) -> tuple[tuple[str, Any], ...]:
    """Return one per-wheel signal list, as ``(wheel, signal)`` pairs."""
    from ..schema.dynamic import TimeSignal

    declared = document.get(key)
    if declared is None:
        return ()
    if not isinstance(declared, Mapping):
        raise TypeError(f"{key} must map a wheel to its signal")
    return tuple(
        (str(wheel), TimeSignal.model_validate(signal))
        for wheel, signal in declared.items()
    )


def _wheel_speeds(document: Mapping[str, Any]) -> tuple[tuple[str, float], ...]:
    declared = document.get("initial_wheel_speeds")
    if declared is None:
        return ()
    if not isinstance(declared, Mapping):
        raise TypeError("initial_wheel_speeds must map a wheel to its speed")
    return tuple((str(wheel), float(speed)) for wheel, speed in declared.items())


def _initial_states(document: Mapping[str, Any]) -> tuple[Any, ...]:
    from ..schema.dynamic import InitialBodyState

    declared = document.get("initial_states")
    if declared is None:
        return ()
    return tuple(InitialBodyState.model_validate(row) for row in declared)


def _mode(value: Any) -> str:
    """Return the suspension mode a document states, or refuse by name."""
    if value is None:
        return "auto"
    mode = str(value)
    if mode not in _MODES:
        raise ValueError(f"suspension_mode must be one of {list(_MODES)}, got {value!r}")
    return mode


def _sign(value: Any) -> int:
    sign = int(value)
    if sign not in (-1, 1):
        raise ValueError(f"initial_velocity_sign must be -1 or 1, got {value!r}")
    return sign
