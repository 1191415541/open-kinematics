"""Translate engineering-unit compatibility declarations into physical graph data."""

from __future__ import annotations

from dataclasses import replace
from typing import Any, Literal

import numpy as np

from ..modeling.coordinates import AssemblyCapabilities, CapabilityError
from ..templates.builtin import CHASSIS, STEERING_GUIDED, WHEEL
from ..templates.instantiate import SubsystemInstance, instantiate
from ..templates.model import ConnectionDefinition

LEGACY_DRIVE_COORDINATES = {
    "suspension": frozenset({"wheel_drive_L", "wheel_drive_R"}),
    "wheel": frozenset({"wheel_drive_L", "wheel_drive_R"}),
    "steering": frozenset({"rack_drive", "rack_neutral"}),
    "chassis": frozenset(), "brake": frozenset(), "drive": frozenset(),
    "anti_roll_bar": frozenset(),
}
ALL_SUBSYSTEMS = frozenset(LEGACY_DRIVE_COORDINATES)


def coordinate_declarations(subsystems: frozenset[str]) -> frozenset[str]:
    """Translate old role-only documents into explicit coordinate declarations."""
    unknown = subsystems - ALL_SUBSYSTEMS
    if unknown:
        raise CapabilityError(f"unknown subsystem role(s) {sorted(unknown)}")
    return frozenset().union(*(LEGACY_DRIVE_COORDINATES[role] for role in subsystems))


def capabilities_for(*, subsystems: frozenset[str], body_names: frozenset[str]) -> AssemblyCapabilities:
    """Compatibility adapter for callers supplying legacy role declarations."""
    return AssemblyCapabilities(
        subsystems=frozenset(subsystems),
        drive_coordinates=coordinate_declarations(subsystems),
        body_names=frozenset(body_names),
    )


def role_instance(context: Any, role: str) -> SubsystemInstance:
    """Resolve the compatibility preset selected for one role."""
    requested = context.request.role_instance(role)
    if isinstance(requested, SubsystemInstance):
        return requested
    defaults = {"chassis": CHASSIS, "steering": STEERING_GUIDED, "wheel": WHEEL}
    return instantiate(defaults[role], mode=context.mode)


def body_data(context: Any, parts: Any, connections: Any, *, use_specs: bool = True, ignore_specs: bool = False) -> list[dict[str, Any]]:
    """Translate legacy body properties without creating runtime entities."""
    rows = []
    for part in parts:
        name = part.name
        spec = context.body_specs.get(name) if use_specs and not ignore_specs else None
        row: dict[str, Any] = {"name": name, "fixed": part.fixed}
        if spec is not None:
            row.update(
                mass=spec.mass, inertia=spec.inertia,
                position=spec.pose.translation.as_tuple(),
                quaternion=spec.pose.rotation.as_tuple(),
                center_of_mass=spec.center_of_mass.as_tuple(), fixed=spec.fixed,
            )
        elif use_specs and part.mass > 0:
            side = name.rsplit("_", 1)[-1]
            if side not in context.request.sides:
                side = context.request.sides[0]
            center = context.part_placement(name, connections, side)
            row.update(mass=part.mass, inertia=np.eye(3)*part.mass*8.0**2,
                       center_of_mass=np.zeros(3) if center is None else center)
        rows.append(row)
    return rows


def side_body_data(context: Any, side: str) -> list[dict[str, Any]]:
    """Return the body data declared on one side."""
    template = context.request.instantiated_suspension.template
    parts = tuple(part for part in template.parts if part.name.endswith("_" + side))
    return body_data(context, parts, template.connections)


def side_body_order(request: Any) -> tuple[str, ...]:
    """Preserve the declaration's recorded body order."""
    return tuple(
        part.name for part in request.instantiated_suspension.template.parts
        if (request.carries("chassis") or part.name != "chassis")
        and (request.carries("steering") or part.name not in {"rack", "rack_housing"})
        and (not part.name.endswith(("_L", "_R")) or part.name.rsplit("_", 1)[-1] in request.sides)
    )


def suspension_connections(context: Any, side: str) -> tuple[ConnectionDefinition, ...]:
    """Normalise legacy implicit endpoint conventions once, before interpretation."""
    template = context.request.instantiated_suspension.template
    declared = [row for row in template.connections if row.owner.endswith("_" + side)]
    inboard = [row for row in declared if row.label in {"inner_front", "inner_rear"}]
    outer = [row for row in declared if row.label == "outer" and row.role in {"upper_outer", "lower_outer"}]
    other = [row for row in declared if row not in inboard and row not in outer]
    result = []
    for row in (*inboard, *outer, *other):
        if row in inboard:
            row = replace(row, far_owner=row.far_owner or "chassis", first_body="far",
                          far_fallbacks=row.far_fallbacks or ("ground",),
                          ideal_joint=row.ideal_joint or "spherical")
        elif row.role == "tie_inner" and row.far_owner:
            row = replace(row, name=f"rack_tie_joint_{side}", first_body="far", far_fallbacks=row.far_fallbacks or ("chassis", "ground"), record_far_point=False)
        elif row.role == "tie_outer" and row.joint:
            row = replace(row, name=f"tie_upright_joint_{side}")
        elif row.role == "wheel_center" and row.joint:
            row = replace(row, first_body="far", axis=row.axis or (0.0, 1.0, 0.0))
        result.append(row)
        if row.role == "wheel_center" and row.joint:
            result.append(replace(row, name=f"{row.owner}_wheel_center", joint=None,
                                  bushing=None, far_owner="", label="wheel_center",
                                  record_connection=False))
    return tuple(result)


def steering_connections(context: Any) -> tuple[ConnectionDefinition, ...]:
    """Translate the legacy fixed/guided support choice into joint declarations."""
    template = role_instance(context, "steering").template
    mounts = [row for row in template.connections if row.role == "rack_center" and row.owner == "rack"]
    if len(mounts) != 1:
        raise ValueError(f"steering template {template.name!r} needs exactly one rack_center connection on rack")
    mount = mounts[0]
    housing = any(part.name == "rack_housing" for part in template.parts)
    if context.model.rack_fixed_to_chassis:
        guide = replace(mount, name="rack_fixed_to_chassis", joint="fixed", far_owner="chassis")
    else:
        guide = replace(mount, far_owner="rack_housing" if housing else mount.far_owner or "chassis",
                        axis=context.model.rack_axis.as_tuple())
    guide = replace(guide, first_body="far", far_fallbacks=("chassis", "ground"),
                    record_connection=False, record_far_point=not housing)
    rows = [guide]
    if housing:
        rows.append(ConnectionDefinition(
            "housing_mount", mount.role, "fixed", owner="rack_housing", label="mount",
            far_owner="chassis", far_label=mount.far_label or mount.role,
            first_body="far", far_fallbacks=("ground",),
            record_connection=False, record_owner_point=False,
        ))
    return tuple(rows)


def declared_ports(context: Any) -> tuple[Any, ...]:
    """Return the selected template's semantic interfaces."""
    return tuple(context.request.instantiated_suspension.template.ports)


def wheel_body_data(context: Any) -> list[dict[str, Any]]:
    """Return wheel bodies with their original independent inertial source."""
    template = role_instance(context, "wheel").template
    parts = tuple(part for part in template.parts if part.name not in context.bodies)
    return body_data(context, parts, template.connections, ignore_specs=True)


def wheel_mount(context: Any, side: str) -> ConnectionDefinition:
    """Resolve the declared wheel attachment on one side."""
    template = role_instance(context, "wheel").template
    rows = [row for row in template.connections if row.role == "wheel_center" and row.owner.endswith("_" + side)]
    if len(rows) != 1:
        raise ValueError(f"wheel template {template.name!r}: side {side!r} needs exactly one wheel-centre mount")
    return rows[0]


def element_rows(context: Any, placeholders: Any = ()) -> list[Any]:
    """Translate old property lists to ordered, geometry-resolved primitive rows."""
    from ..subsystems.geometry import resolve_body
    from ..subsystems.types import ResolvedElement

    def two_ended(kind: str, spec: Any, side: Literal["L", "R"]) -> Any:
        a = resolve_body(spec.body_a, side, context.bodies)
        b = resolve_body(spec.body_b, side, context.bodies)
        return ResolvedElement(
            kind=kind, name=f"{spec.name}_{side}", spec=spec,
            body_a=a, point_a=context.local(a, context.attachment_point(spec.point_a, side)),
            body_b=b, point_b=context.local(b, context.attachment_point(spec.point_b, side)),
        )

    rows = []
    for side in context.request.sides:
        for kind, specs in (("spring", context.model.springs), ("damper", context.model.dampers)):
            rows.extend(two_ended(kind, spec, side) for spec in specs)
        if context.request.carries("wheel"):
            mount = wheel_mount(context, side)
            owner = mount.owner
            if owner not in context.bodies and f"upright_{side}" in context.bodies:
                owner = f"upright_{side}"
            rows.extend(ResolvedElement(
                kind="tire", name=f"tire_{side}", spec=spec, body_a=owner,
                point_a=context.local(owner, context.mirror(side, mount.role)),
            ) for spec in context.model.tires)
        rows.extend(two_ended("bump_stop", spec, side) for spec in context.model.stops)
    for spec in context.model.anti_roll_bars:
        ends = {}
        for side in ("L", "R"):
            matches = [row.far_owner for row in context.request.instantiated_suspension.template.connections
                       if row.role == "wheel_center" and row.far_owner and row.owner.endswith("_" + side)]
            if not matches:
                raise ValueError(f"the suspension template declares no wheel-end body for side {side!r}")
            ends[side] = matches[0]
        rows.append(ResolvedElement(
            kind="anti_roll_bar", name=spec.name, spec=spec,
            body_a=ends["L"], point_a=context.local(ends["L"], spec.left_link_point.as_array()),
            body_b=ends["R"], point_b=context.local(ends["R"], spec.right_link_point.as_array()),
        ))
    if context.mode == "C":
        for side in context.request.sides:
            for spec in context.model.bushings:
                a = resolve_body(spec.body_a, side, context.bodies)
                b = resolve_body(spec.body_b, side, context.bodies)
                rows.append(ResolvedElement(
                    kind="bushing", name=f"{spec.name}_{side}", spec=spec, body_a=a, body_b=b,
                    local_pose_a=context.local_attachment(spec.pose_a, side, a),
                    local_pose_b=context.local_attachment(spec.pose_b, side, b),
                ))
        rows.extend(placeholders)
    return rows


def torque_parameter_data(role: str, slots: Any, *, share: float, demand: float = 1.0, gain_scale: float = 1.0, demand_source: int = 0, demand_tire: int = -1, wheel: str | None = None) -> dict[str, Any]:
    """Compile a compatibility parameter recipe without changing its force law."""
    from ..subsystems.types import WHEELS
    from ..templates.builtin import TORQUE_PARAMETER_RECIPES

    if wheel is not None and wheel not in WHEELS:
        raise ValueError(f"unknown wheel {wheel!r}")
    recipe = TORQUE_PARAMETER_RECIPES[role]
    amplitude = torque_amplitude_data(role, slots, share=share, demand=demand)
    cap = torque_amplitude_data(role, slots, share=share, demand=1.0)
    return {
        "stiffness": (abs(amplitude) if recipe["absolute_gain"] else amplitude) * gain_scale,
        "max_torque": cap * gain_scale, "axis_a": (0.0, 1.0, 0.0),
        "demand_source": demand_source, "demand_tire": demand_tire,
    }


def torque_amplitude_data(role: str, slots: Any, *, share: float, demand: float) -> float:
    """Evaluate the declared parameter recipe, including its signed input range."""
    from ..authoring.function_program import evaluate_constant_function
    from ..templates.builtin import TORQUE_PARAMETER_RECIPES

    recipe = TORQUE_PARAMETER_RECIPES[role]
    low, high = recipe["range"]
    if not low <= demand <= high:
        raise ValueError(f"{recipe['input_name']} must be normalized to [{low:g}, {high:g}]; got {demand!r}")
    values = {**slots, **recipe["constants"], "share": share, "input": demand}
    return evaluate_constant_function(recipe["expression"], values)


def wheel_shares(driveline: Any) -> dict[str, float]:
    """Translate the compatibility driveline's explicit allocation."""
    from ..subsystems.types import WHEELS

    shares = dict(zip(WHEELS, driveline.drive_split))
    if driveline.maximum_drive_torque > 0.0 and not driveline.driven_wheels:
        raise ValueError("drive torque requires driveline.driven_wheels")
    for name in sorted(set(driveline.driven_wheels)):
        if shares[name] <= 0.0:
            raise ValueError(f"each driven wheel requires a positive drive_split; {name!r} has {shares[name]!r}")
    return shares
