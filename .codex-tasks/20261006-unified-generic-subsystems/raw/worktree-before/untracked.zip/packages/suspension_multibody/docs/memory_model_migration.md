# 从旧车型模型迁移到通用文档 API

本文面向已经用过 `FrontAxleModel` / `VehicleModel` 的调用方，说明这两个类为什么
被删除、替代物是什么，以及每一类旧用法应当改写成什么。迁移后的等价性由测试保证，
本文只给出改写对照。

## 为什么删除

这两个类是**装配层与文档层之间的接口类型**：装配入口的参数写死了它们，所以一个
文件、一个 Python 对象和一个预设都必须先变成这两个类之一才能进入装配。这带来两个
后果：文件格式与 Python 类成为同一份物理的两套描述，容易漂移；调用方想表达这两个
类没有描述过的拓扑时无路可走。

替代方案分两层，各自职责明确：

| 层 | 承担者 | 职责 |
|---|---|---|
| 文档层 | `TemplateDocument` / `SubsystemDocument` / `AssemblyDocument` / `RigDocument` | 存声明：形状、参数、引用、试验台绑定 |
| 装配层 | `AxleInput` / `VehicleInput`（结构化协议） | 声明装配器**读什么**，由任何满足该形状的对象实现 |

v1 模型文件格式仍在，读取结果改为声明值 `AxleDeclaration` / `VehicleDeclaration`。
两者都是数据，不再承担"唯一的合法接口"这一角色。

## 逐项对照

| 旧用法 | 新用法 | 位置 |
|---|---|---|
| `FrontAxleModel(...)` | `AxleDeclaration(...)` | `suspension_multibody.schema.model` |
| `VehicleModel(...)` | `VehicleDeclaration(...)` | `suspension_multibody.schema.vehicle` |
| `FrontAxleModel.model_validate(payload)` | `AxleDeclaration.model_validate(payload)` | 同上（字段名与校验未变） |
| `VehicleModel.model_validate(payload)` | `VehicleDeclaration.model_validate(payload)` | 同上 |
| `load_model(path)` | （已退役；用户改用 `AssemblyDocument`） | — |
| `load_vehicle_model(path)` | （已退役；用户改用 `AssemblyDocument`） | — |
| `front_axle_model_from(subsystem)` | `axle_declaration_from(subsystem)` | `suspension_multibody.authoring.bridge` |
| `front_axle_model_for(subsystem)` | `axle_declaration_for(subsystem)` | `suspension_multibody.authoring.solver` |
| `document_axle_from` / `document_axle_for` | 同上二者（已合并为唯一派生） | 同上 |
| `DocumentAxle` | `AxleDeclaration`（不再有第二个值类型） | — |
| `vehicle_model_from(document)` | `vehicle_declaration_from(document)` | `suspension_multibody.authoring.vehicle` |
| `front_axle_model_from_contract(contract, mass=)` | `axle_declaration_from_contract(...)` | `suspension_multibody.adapters` |

`simulate` 是唯一的公开仿真入口：一个 `AssemblyDocument` 加一个 case 文档。旧的四
个分散入口（`run_case` / `run_dynamic_case` / `run_axle_dynamics` /
`run_vehicle_dynamics`）连同它们的 SI 建模路线一起退役；能力仍在，只是降级为包内
拼写（`kc_case_run` / `replay_case` / `run_axle` / `vehicle_dynamics_run`），
**不是**用户建模入口。

## 双叉臂这类常见形状：改用 Preset

以前"造一个双叉臂"意味着构造 `FrontAxleModel`。现在由预设给出**通用文档对象**，
它可以被拆开、改一个坐标、存盘再加载，和手写声明完全等价：

```python
from suspension_multibody.presets import (
    double_wishbone_subsystem,
    double_wishbone_template,
    standalone_axle,
)

template = double_wishbone_template()      # TemplateDocument，path 为 None
subsystem = double_wishbone_subsystem(hardpoints=..., spring=..., damper=...)
assembly = standalone_axle((subsystem,), rig=rig)
```

预设不发明任何数字：`spring` / `damper` / `hardpoints` 必须由调用方给出，否则
得到的会是一个没人选择过的模型。

## 内存路线与文件路线是同一个 run

`simulate` 接受文件路径、`AssemblyDocument`、已绑定 rig 的 `SimulationAssembly`
三种形态，全部归一化为同一次编译与同一次提交。内存路线在文档构造完成后不再读取
任何建模文件。

完整可运行示例见 `docs/composable_extension_examples.md` 的 E-4，它由发布探针
`check_composable_release.py --skip-isolation` 实际执行。

## 边界与保留项

- **结果读取未受影响**：历史结果类型（`DynamicResultBundle` 等）与两个旧模型无关，
  `load_dynamic_result` 行为不变。
- **冻结数值未移动**：`dynamic_hash_sentinel` 的比对基线逐字节一致（26 artifact）。
- **v1 模型文件格式仍可读**：字段名、默认值与校验规则都保留，因此迁移前的模型文件仍
  能读进 `AxleDeclaration` / `VehicleDeclaration`。但两个 v1 *加载器*
  （`load_axle_declaration` / `load_vehicle_declaration`）已随建模路线退役；这四个
  名字（两个加载器加两个声明类型的根导出）由
  `tests/architecture/test_retired_entries_gate.py` 守住。
- **旧名已被结构门禁止回归**：`tests/architecture/test_no_legacy_vehicle_models.py`
  是 AST 检查，已接入 `just gate-architecture`；它同时验证检测器能抓住注入的旧引用，
  也验证解释退役的注释/文档不被误报。
