"""
02: every public simulation entry returns the one ``SimulationRun`` envelope.

The four decoded result types (``ResultBundle``, ``AxleDynamicsResult``,
``TimeSeriesResult``, and the envelope itself) used to be four return types, so a
caller had to know which door it came through to read the numbers.  These tests
hold the two properties that make the change safe:

* the entry returns the envelope, and
* the fields the old return type carried are still readable, with the same values.

The second property is the one that matters.  Asserting only that a call returns
would pass even if every field had silently become ``None``, so each check below
reads the actual data off both paths and compares.
"""
from __future__ import annotations

import numpy as np
import pytest

from suspension_multibody import api
from suspension_multibody.schema import CaseSpec, DisplacementControl, MassSpec
from suspension_multibody.schema.model import AxleDeclaration
from suspension_multibody.simulation.runner import SimulationRun

HARDPOINTS = {
    "uca_front": [-100, -500, 400],
    "uca_rear": [100, -500, 400],
    "uca_outer": [0, -700, 450],
    "lca_front": [-120, -500, 150],
    "lca_rear": [120, -500, 150],
    "lca_outer": [0, -700, 150],
    "tierod_inner": [100, -400, 250],
    "tierod_outer": [50, -700, 250],
    "wheel_center": [0, -700, 300],
    "rack_center": [0, 0, 250],
}


def _model() -> AxleDeclaration:
    return AxleDeclaration(hardpoints=dict(HARDPOINTS), mass=MassSpec(sprung_mass=1000))


def _k_case() -> CaseSpec:
    return CaseSpec(
        mode="K",
        controls=(
            DisplacementControl(target="wheel_travel_left", values=(0.0, 20.0)),
        ),
    )


def test_run_case_returns_the_envelope() -> None:
    run = api.kc_case_run(_model(), _k_case())
    assert isinstance(run, SimulationRun)


def test_the_bundle_rides_on_result() -> None:
    from suspension_multibody.schema import ResultBundle

    run = api.kc_case_run(_model(), _k_case())
    assert isinstance(run.result, ResultBundle)


def test_the_old_fields_are_identical_on_both_paths() -> None:
    """
    Every field the caller used to read is the same value read either way.

    ``run.states`` and ``run.result.states`` must be the same objects, not merely
    equal counts: a fall-through that rebuilt the tuple would hide a divergence.
    """
    run = api.kc_case_run(_model(), _k_case())
    bundle = run.result

    assert run.states == bundle.states
    assert run.component_loads == bundle.component_loads
    assert run.bushings == bundle.bushings
    assert run.diagnostics == bundle.diagnostics
    assert run.manifest.run_id == bundle.manifest.run_id
    assert run.manifest.state_count == bundle.manifest.state_count
    assert run.manifest.provenance.model_hash == bundle.manifest.provenance.model_hash
    # The state payloads themselves, not only their container.
    assert [s.state_id for s in run.states] == [s.state_id for s in bundle.states]
    for left, right in zip(run.states, bundle.states):
        assert left.constraint_residual == right.constraint_residual
        assert left.tire_compression == right.tire_compression


def test_status_comes_from_the_kernel_on_a_submitted_run() -> None:
    run = api.kc_case_run(_model(), _k_case())
    assert run.raw is not None
    assert run.status == run.raw.status == "success"


def test_a_name_on_neither_the_envelope_nor_the_result_is_an_error() -> None:
    run = api.kc_case_run(_model(), _k_case())
    with pytest.raises(AttributeError, match="no attribute 'not_a_field'"):
        run.not_a_field


def test_an_explicit_read_off_result_is_always_available() -> None:
    """A caller that wants to be explicit never has to know the fall-through."""
    run = api.kc_case_run(_model(), _k_case())
    assert run.result is not None
    assert len(run.result.states) == len(run.states)


def test_a_replay_run_carries_its_series_and_no_compiled_request() -> None:
    """
    A prescribed-motion replay submits nothing, so the envelope says so.

    ``run_dynamic_case``'s replay path produces a ``TimeSeriesResult`` without a
    contract submission.  The envelope still returns the series (so the fields
    read off the run), and asking for ``.request`` reports that there is none
    rather than handing back ``None`` for a caller to trip over later.
    """
    from suspension_multibody.results.timeseries import TimeSeriesResult
    from suspension_multibody.schema import (
        DynamicCaseSpec,
        DynamicSolverSettings,
        PrescribedMotion,
        TimeSignal,
    )

    case = DynamicCaseSpec(
        name="replay",
        mode="axle_dynamic",
        solver=DynamicSolverSettings(
            integrator="quasi_static", end_time=1e-3, step_size=1e-3
        ),
        prescribed_motions=(
            PrescribedMotion(
                target="wheel_travel_left", displacement=TimeSignal(constant=0.0)
            ),
        ),
    )
    run = api.replay_case(_model(), case)

    assert isinstance(run, SimulationRun)
    assert isinstance(run.result, TimeSeriesResult)
    assert run.compiled is None
    assert run.raw is None
    # The series fields read straight off the run, and its status falls back to
    # the series rather than defaulting to a claim the run never made.
    assert np.asarray(run.times_s).size == np.asarray(run.result.times_s).size
    assert run.status == run.result.status
    with pytest.raises(AttributeError, match="carries no compiled request"):
        run.request
