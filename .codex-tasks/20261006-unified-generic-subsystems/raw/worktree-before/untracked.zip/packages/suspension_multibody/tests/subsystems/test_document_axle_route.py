"""
The document route reaches a run through one derivation and the protocol.

``axle_declaration_for`` turns a file subsystem into the facts the composition
reads.  The composition reads them through ``AxleInput``, so what these tests pin
is that the document route produces a value satisfying that protocol and
assembles the same runtime an object-built axle does -- one derivation, two
suppliers, one runtime.
"""

from __future__ import annotations

import json
from pathlib import Path

from suspension_multibody.authoring.documents import AssemblyDocument
from suspension_multibody.authoring.solver import (
    axle_declaration_for,
)
from suspension_multibody.preparation.kc_quasi_static import assembly_for
from suspension_multibody.subsystems.types import AxleInput
from tests.authoring.fixtures import write_builtin_axle_project


def _suspension(paths: dict[str, Path]):
    assembly = AssemblyDocument.load(paths["assembly"])
    return [
        entry for entry in assembly.entries if entry.functional_role == "suspension"
    ][0]


def _fingerprint(runtime: object) -> dict[str, object]:
    """Describe a runtime by the entities a solve would read."""

    def names(items: object) -> list[str]:
        return sorted(str(getattr(item, "name", item)) for item in (items or ()))

    return {
        "bodies": names(getattr(runtime, "bodies", ())),
        "points": sorted(str(name) for name in (getattr(runtime, "points", {}) or {})),
        "constraints": names(getattr(runtime, "constraints", ())),
        "elements": names(getattr(runtime, "elements", ())),
    }


def test_the_document_axle_satisfies_the_composition_protocol(tmp_path: Path) -> None:
    """
    The document route's axle is a value the composition accepts structurally.

    That is the property that matters: the composition reads facts, not a class.
    A file route whose product was the only shape accepted could not be retired
    without rewriting the file route, which is what the protocol removes.
    """
    paths = write_builtin_axle_project(tmp_path)
    entry = _suspension(paths)
    axle = axle_declaration_for(entry.subsystem, name="doc_axle", entry=entry)
    assert isinstance(axle, AxleInput)
    assert axle.name == "doc_axle"
    assert axle.hardpoints


def test_the_document_axle_assembles_the_same_runtime_as_the_object_path(
    tmp_path: Path,
) -> None:
    """
    One derivation, two suppliers, one runtime.

    A declaration built the same way twice must assemble the same entities; the
    comparison is entity-by-entity rather than "both succeeded", because a
    runtime that merely succeeded could still carry a different body set.
    """
    paths = write_builtin_axle_project(tmp_path)
    entry = _suspension(paths)

    first = axle_declaration_for(entry.subsystem, name="axle", entry=entry)
    second = axle_declaration_for(entry.subsystem, name="axle", entry=entry)

    from_first = assembly_for(first, mode="K", rig="kc_quasi_static")
    from_second = assembly_for(second, mode="K", rig="kc_quasi_static")

    assert _fingerprint(from_second) == _fingerprint(from_first)


def test_the_document_axle_carries_the_documented_facts(tmp_path: Path) -> None:
    """The facts are the ones the file stated, not invented by the new type."""
    paths = write_builtin_axle_project(tmp_path)
    entry = _suspension(paths)
    axle = axle_declaration_for(entry.subsystem, name="doc_axle", entry=entry)

    template = entry.subsystem.template
    # Bodies are the template's dynamic (non-fixed) parts, mirrored to both sides.
    assert axle.bodies
    assert all(spec.name for spec in axle.bodies)
    assert axle.hardpoints
    # The topology the composition switches on is the schema default for a
    # document.
    assert axle.topology == "symmetric_proxy"
    assert len(axle.springs) == len(
        [e for e in template.payload["elements"] if e["type"] == "spring"]
    )


def test_a_saved_project_reaches_a_run_without_reading_it_back(tmp_path: Path) -> None:
    """
    End to end: a file project, through the document builder, to a runtime.

    The only classes involved are the documents and the composition's own values.
    """
    paths = write_builtin_axle_project(tmp_path)
    entry = _suspension(paths)
    document = axle_declaration_for(entry.subsystem, name="axle", entry=entry)
    runtime = assembly_for(document, mode="K", rig="kc_quasi_static")

    # The project is deleted *before* the assertion, so a lazy read would fail.
    for path in paths.values():
        path.unlink()
    assert runtime.bodies
    assert json.dumps(sorted(runtime.bodies)) == json.dumps(sorted(runtime.bodies))
