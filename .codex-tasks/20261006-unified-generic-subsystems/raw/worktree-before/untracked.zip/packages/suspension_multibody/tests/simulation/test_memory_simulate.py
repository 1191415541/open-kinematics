"""
`simulate` accepts a model that was never a file.

The document entry already took a path, a loaded document and a rig-bound one.
This module pins the fourth spelling -- an assembly built entirely in memory --
and, more importantly, pins that it is not a *different* run: the same case must
produce the same submission and the same numbers, and the memory route must reach
that run without reading the project directory back.

The tests run the real kernel.  A mocked submission would let the memory route
pass while it submitted a differently-shaped document, which is the failure worth
catching.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from suspension_multibody import api
from suspension_multibody.authoring import (
    load_assembly,
    load_rig,
    load_subsystem,
    load_template,
)
from suspension_multibody.authoring.documents import (
    AssemblyDocument,
    SimulationAssembly,
)
from suspension_multibody.authoring.properties import ElementPropertyDocument
from suspension_multibody.axle_dynamics.schema import AxleSolverSettings
from tests.authoring.fixtures import write_builtin_axle_project


def _case_document(name: str, sections: dict[str, Any]) -> dict[str, Any]:
    return {
        "contract": "multibody-case",
        "contract_version": 1,
        "kind": "case",
        "family": "kc_quasi_static",
        "name": name,
        "time": {"start_s": 0.0, "end_s": 1e-3, "step_s": 1e-3},
        "solver": AxleSolverSettings().model_dump(mode="json"),
        **sections,
    }


_K_SECTION: dict[str, Any] = {
    "k": {
        "wheel_values_mm": [0.0, 20.0],
        "rack_values_mm": [],
        "drive": "wheel_center",
        "left_right_mode": "symmetric",
        "axis_map": {"wheel": ["wheel_drive_L", "wheel_drive_R"]},
    }
}


def _project(root: Path) -> dict[str, Path]:
    directory = root / "project"
    directory.mkdir(parents=True, exist_ok=True)
    paths = write_builtin_axle_project(directory)
    payload = json.loads(paths["rig"].read_text(encoding="utf-8"))
    payload["bench"] = "kc_quasi_static"
    paths["rig"].write_text(json.dumps(payload), encoding="utf-8")
    return paths


def _in_memory_assembly(paths: dict[str, Path]) -> SimulationAssembly:
    """Build the same axle the files describe, without keeping any of the files."""
    documents = _in_memory_documents(paths)
    return SimulationAssembly.bind(documents["assembly"])


def _in_memory_documents(paths: dict[str, Path]) -> dict[str, Any]:
    """
    Read the project once, into documents that no longer need the directory.

    Every subsystem the assembly names is supplied, not only the suspension: a
    partial set would make the in-memory assembly a different device from the one
    the files describe, and the difference would show up as a refusal rather than
    as a wrong number.
    """
    declaration = json.loads(paths["assembly"].read_text(encoding="utf-8"))
    templates = {
        "suspension.tpl.json": load_template(paths["template"]),
        "chassis.tpl.json": load_template(paths["chassis_template"]),
    }
    subsystems = {}
    laws = {}
    for row in declaration["subsystems"]:
        subsystem_path = paths["assembly"].parent / row["ref"]
        payload = json.loads(subsystem_path.read_text(encoding="utf-8"))
        template = templates[payload["template"]]
        subsystems[row["ref"]] = load_subsystem(payload, template=template)
        bound = {
            slot: ElementPropertyDocument.load(subsystem_path.parent / name)
            for slot, name in payload["property_bindings"].items()
        }
        if bound:
            laws[row["ref"]] = bound
    assembly = load_assembly(
        declaration,
        subsystems=subsystems,
        properties=laws,
        rig=load_rig(paths["rig"]),
    )
    return {"assembly": assembly}


def test_an_in_memory_assembly_runs_through_simulate(tmp_path: Path) -> None:
    paths = _project(tmp_path)
    run = api.simulate(_in_memory_assembly(paths), _case_document("memory", _K_SECTION))
    assert run.status == "success", run.raw.failure_evidence
    assert run.request.rig == "kc_quasi_static"


def test_the_memory_assembly_is_the_same_run_as_the_file(tmp_path: Path) -> None:
    """
    The file and the in-memory assembly submit the same document.

    Comparing the compiled model document is what makes "the same run" checkable:
    two runs could both succeed while the memory route emitted a model with a
    different body set or different marker values.
    """
    paths = _project(tmp_path)
    case = _case_document("same", _K_SECTION)

    from_file = api.simulate(paths["assembly"], case)
    in_memory = api.simulate(_in_memory_assembly(paths), case)

    assert from_file.status == "success", from_file.raw.failure_evidence
    assert in_memory.status == "success", in_memory.raw.failure_evidence
    assert in_memory.compiled.model_document == from_file.compiled.model_document
    assert in_memory.compiled.case_document == from_file.compiled.case_document


def test_the_memory_assembly_runs_with_the_project_files_gone(tmp_path: Path) -> None:
    """
    Nothing under the project directory is read once the documents exist.

    This is the difference the object route exists to make: a caller holding the
    model does not need the files to run it.  The compiled artefacts are written
    outside the project, and the kernel library is loaded by the package, so
    removing the project tree is a fair test of "no modelling file was read".
    """
    paths = _project(tmp_path)
    assembly = _in_memory_assembly(paths)
    shutil.rmtree(paths["assembly"].parent)

    run = api.simulate(assembly, _case_document("gone", _K_SECTION))
    assert run.status == "success", run.raw.failure_evidence


def test_a_memory_assembly_is_not_rebound_from_a_path(tmp_path: Path) -> None:
    """
    Binding uses the rig the assembly carries, not a path it no longer has.

    A loaded ``AssemblyDocument`` used to be re-bound from its own path; for an
    in-memory assembly that path does not exist, so the binding has to come from
    the object.  The check is the run succeeds with the rig the document names.
    """
    paths = _project(tmp_path)
    assembly = _in_memory_documents(paths)["assembly"]
    assert isinstance(assembly, AssemblyDocument)
    assert assembly.path is None

    bound = SimulationAssembly.bind(assembly)
    assert bound.rig.name == assembly.rig.name
    run = api.simulate(bound, _case_document("bound", _K_SECTION))
    assert run.status == "success", run.raw.failure_evidence
