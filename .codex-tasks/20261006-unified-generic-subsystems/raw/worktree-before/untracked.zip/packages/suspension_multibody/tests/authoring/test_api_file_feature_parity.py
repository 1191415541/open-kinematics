"""
The professional API covers what the file route covers.

The epic's third goal is that the memory API is not a *subset* of the file
route: a second-party developer who never writes an assembly file has to reach
the same modelling, binding, property, case and solve capabilities the file
route reaches.  This module is where that claim is checked item by item, against
the frozen capability matrix from subtask 01 (``CAPABILITIES.csv``), whose
``capability_id`` values are named in each test.

Two rules keep it honest:

* every capability is checked on **both** routes and compared, so a test cannot
  pass by exercising only the memory side -- the point is parity, not presence;
* the comparison is over the *facts* each route produces -- the compiled model
  and case documents, the entities an assembly is made of, the declaration a run
  reads -- and not over "both returned something", because two routes that both
  succeed while disagreeing about the axle are exactly the drift this work
  removes.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from suspension_multibody import api
from suspension_multibody.authoring import (
    AssemblyDocument,
    TemplateDocument,
    load_subsystem,
)
from suspension_multibody.authoring.documents import SimulationAssembly
from suspension_multibody.authoring.properties import ElementPropertyDocument
from suspension_multibody.authoring.solver import axle_declaration_for
from suspension_multibody.presets import (
    double_wishbone_subsystem,
    double_wishbone_template,
)
from suspension_multibody.schema.model import AxleDeclaration
from tests.authoring.fixtures import write_builtin_axle_project

# --- fixtures ---------------------------------------------------------------


def _project(tmp_path: Path) -> dict[str, Path]:
    """
    Write the built-in axle project, with the bench the run needs.

    The fixture project states no ``bench``, and a rig bound to no bench has
    nothing to drive with -- so the one field a file-driven run requires is added
    here rather than inside the shared fixture, where it would change what other
    modules are testing.
    """
    directory = tmp_path / "project"
    directory.mkdir(parents=True, exist_ok=True)
    paths = write_builtin_axle_project(directory)
    payload = _read_json(paths["rig"])
    payload["bench"] = "kc_quasi_static"
    paths["rig"].write_text(_write_json(payload), encoding="utf-8")
    return paths


def _read_json(path: Path) -> dict[str, Any]:
    import json

    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(payload: dict[str, Any]) -> str:
    import json

    return json.dumps(payload)


def _case(name: str = "parity-k") -> dict[str, Any]:
    """Return the smallest legal K case document."""
    return {
        "contract": "multibody-case",
        "contract_version": 1,
        "kind": "case",
        "family": "kc_quasi_static",
        "name": name,
        "time": {"start_s": 0.0, "end_s": 1e-3, "step_s": 1e-3},
        "solver": {"end_time": 0.001, "step_size": 0.001},
        "k": {
            "wheel_values_mm": [0.0],
            "rack_values_mm": [],
            "drive": "wheel_center",
            "left_right_mode": "symmetric",
            "axis_map": {"wheel": ["wheel_drive_L", "wheel_drive_R"]},
        },
    }


def _suspension_entry(paths: dict[str, Path]) -> Any:
    """Return the fixture project's suspension entry."""
    assembly = AssemblyDocument.load(paths["assembly"])
    return [
        entry for entry in assembly.entries if entry.functional_role == "suspension"
    ][0]


def _declaration_fingerprint(declaration: AxleDeclaration) -> dict[str, Any]:
    """
    Describe a declaration by the fields a composition actually reads.

    ``side`` and ``mass`` are deliberately absent: they are format fields no
    composer reads, so comparing them would test the schema rather than the
    parity this module is about.
    """
    return {
        "name": declaration.name,
        "hardpoints": {
            str(key): tuple(round(float(value), 9) for value in point.as_tuple())
            for key, point in declaration.hardpoints.items()
        },
        "bodies": [
            (spec.name, round(float(spec.mass), 9), bool(spec.fixed))
            for spec in declaration.bodies
        ],
        "springs": [(spec.name, round(float(spec.stiffness), 9)) for spec in declaration.springs],
        "dampers": [
            (spec.name, round(float(spec.viscous_damping), 9))
            for spec in declaration.dampers
        ],
        "stops": [spec.name for spec in declaration.stops],
        "tires": [
            (round(float(tire.stiffness), 9), round(float(tire.unloaded_radius), 9))
            for tire in declaration.tires
        ],
        "topology": declaration.topology,
        "rack_fixed_to_chassis": declaration.rack_fixed_to_chassis,
    }


def _linear(name: str, element_type: str, **parameters: float) -> Any:
    """Build one linear property document in memory, with no path."""
    return ElementPropertyDocument.from_payload(
        {
            "document": "element_properties",
            "schema_version": 1,
            "name": name,
            "element_type": element_type,
            "model": "linear",
            "units": {"force": "N", "length": "mm"},
            "parameters": parameters,
        }
    )


#: The coordinates the exported double-wishbone template declares, keyed by the
#: *role* names that template uses.  They are the fixture project's own numbers,
#: so the preset route and the file route describe the same axle.
_COORDINATES: dict[str, list[float]] = {
    "lower_front": [-120.0, -500.0, 150.0],
    "lower_rear": [120.0, -500.0, 150.0],
    "lower_outer": [0.0, -700.0, 150.0],
    "upper_front": [-100.0, -500.0, 400.0],
    "upper_rear": [100.0, -500.0, 400.0],
    "upper_outer": [0.0, -700.0, 450.0],
    "tie_inner": [100.0, -400.0, 250.0],
    "tie_outer": [50.0, -700.0, 250.0],
    "wheel_center": [0.0, -700.0, 300.0],
    "rack_center": [0.0, 0.0, 250.0],
}


# --- C41/C42/C43: the simulate door accepts every documented origin ---------


def test_simulate_accepts_a_path_a_document_and_a_bound_assembly(
    tmp_path: Path,
) -> None:
    """
    C41/C42/C43: all three assembly origins reach one run.

    The spellings differ only in when the rig is read; the *compiled documents*
    are what has to match, because two runs could both succeed while disagreeing
    about a body set or a marker value.
    """
    paths = _project(tmp_path)
    case = _case()
    from_path = api.simulate(paths["assembly"], case)
    from_object = api.simulate(AssemblyDocument.load(paths["assembly"]), case)
    from_bound = api.simulate(
        SimulationAssembly.bind(AssemblyDocument.load(paths["assembly"])), case
    )

    for run in (from_path, from_object, from_bound):
        assert run.status == "success", run.raw.failure_evidence
    assert from_object.compiled.model_document == from_path.compiled.model_document
    assert from_bound.compiled.model_document == from_path.compiled.model_document
    assert from_object.compiled.case_document == from_path.compiled.case_document


def test_simulate_refuses_a_bare_contract_model_document(tmp_path: Path) -> None:
    """
    C43: the *contract model* document is not an assembly, and is refused by name.

    It does not say which assembly it belongs to, so filling that in would be
    guessing the device under test -- the thing the document route exists to stop
    being necessary.  The refusal has to name where a pair of contract documents
    goes instead, or the caller has no next step.
    """
    paths = _project(tmp_path)
    with pytest.raises(TypeError, match="run_request"):
        api.simulate(_read_json(paths["template"]), _case())


def test_the_memory_route_reads_the_project_without_the_directory(
    tmp_path: Path,
) -> None:
    """
    C59: once the documents exist, no modelling file is read again.

    The project tree is removed *before* the run, so a lazy read fails rather
    than passing quietly -- which is the only way this property can be observed
    from outside.
    """
    import shutil

    from suspension_multibody.authoring import load_rig
    from suspension_multibody.authoring.documents import load_assembly, load_subsystem

    paths = _project(tmp_path)
    template = TemplateDocument.load(paths["template"])
    chassis_template = TemplateDocument.load(paths["chassis_template"])
    subsystems = {
        "front.sub.json": load_subsystem(paths["subsystem"], template=template),
        "chassis.sub.json": load_subsystem(
            paths["chassis_subsystem"], template=chassis_template
        ),
    }
    laws = {
        "front.sub.json": {
            "spring": ElementPropertyDocument.load(paths["spring"]),
            "damper": ElementPropertyDocument.load(paths["damper"]),
        }
    }
    assembly = load_assembly(
        _read_json(paths["assembly"]),
        subsystems=subsystems,
        properties=laws,
        rig=load_rig(paths["rig"]),
    )
    bound = SimulationAssembly.bind(assembly)
    shutil.rmtree(paths["assembly"].parent)

    run = api.simulate(bound, _case())
    assert run.status == "success", run.raw.failure_evidence


# --- C44: the case is a document either way --------------------------------


def test_the_reading_comes_from_the_case_document_not_a_parameter(
    tmp_path: Path,
) -> None:
    """
    C44: a K section is a K run, and a document carrying both is refused.

    The mode could have been a parameter; taking it from the document is what
    makes a memory caller unable to ask for a different reading than the one the
    document states.  Both sections present describes two runs, so it is refused
    rather than resolved by precedence.
    """
    paths = _project(tmp_path)
    assembly = AssemblyDocument.load(paths["assembly"])
    both = dict(_case(), c={"paths": [{"name": "fx", "levels_mm": [0.0]}]})
    with pytest.raises(ValueError, match="exactly one of"):
        api.simulate(assembly, both)


def test_a_case_with_neither_reading_is_refused(tmp_path: Path) -> None:
    """C44: neither section means nothing to solve, and it says so."""
    paths = _project(tmp_path)
    assembly = AssemblyDocument.load(paths["assembly"])
    empty = {key: value for key, value in _case().items() if key != "k"}
    with pytest.raises(ValueError, match="neither"):
        api.simulate(assembly, empty)


# --- C58/C60: preset construction, round trip and isolation ----------------


def test_a_preset_subsystem_describes_the_axle_the_files_describe(
    tmp_path: Path,
) -> None:
    """
    C58: the preset is the registered template, not a second description.

    Both routes are built here and their declarations compared, so a preset that
    carried its own numbers -- a model nobody chose -- would show up as a
    difference rather than as a successful construction.
    """
    paths = _project(tmp_path)
    subsystem = load_subsystem(paths["subsystem"])
    from_file = axle_declaration_for(subsystem, name="axle")

    preset = double_wishbone_subsystem(
        hardpoints=_COORDINATES,
        spring=_linear("spring", "spring", stiffness=45.0, free_length=250.0),
        damper=_linear("damper", "damper", viscous_damping=12.0),
    )
    from_preset = axle_declaration_for(preset, name="axle")

    assert from_preset.topology == from_file.topology
    assert set(from_preset.hardpoints) == set(from_file.hardpoints)
    for key, point in from_file.hardpoints.items():
        assert from_preset.hardpoints[key].as_tuple() == point.as_tuple(), key


def test_a_preset_returns_a_document_a_caller_can_edit_and_save(
    tmp_path: Path,
) -> None:
    """
    C58: a preset is a starting point, not a type.

    The same test the file route gets: take it apart, change one field, save it
    and load it back, and the change is the only difference.  A preset that could
    not be taken apart would be the class this work retired, wearing a new name.
    """
    template = double_wishbone_template()
    assert isinstance(template, TemplateDocument)
    assert template.path is None

    edited = template.to_payload()
    edited["name"] = "renamed_preset"
    renamed = TemplateDocument.from_payload(edited)
    written = renamed.save(tmp_path / "preset.tpl.json")
    reloaded = TemplateDocument.load(written)
    assert reloaded.name == "renamed_preset"
    assert reloaded.payload["bodies"] == template.payload["bodies"]


def test_updating_a_declaration_moves_one_field_and_nothing_else(
    tmp_path: Path,
) -> None:
    """
    C60: a parameter update is copy-on-write, so a run cannot pollute a template.

    Two declarations derived from one subsystem must differ in exactly what was
    changed -- and the original must be untouched, which is the half of
    "isolation" a comparison of the two copies cannot see on its own.
    """
    paths = _project(tmp_path)
    subsystem = load_subsystem(paths["subsystem"])
    base = axle_declaration_for(subsystem, name="base")

    first_key = sorted(base.hardpoints)[0]
    original = base.hardpoints[first_key]
    moved_hardpoints = dict(base.hardpoints)
    moved_hardpoints[first_key] = type(original)(
        x=original.x + 25.0, y=original.y, z=original.z
    )
    moved = base.model_copy(update={"hardpoints": moved_hardpoints, "name": "moved"})

    before = _declaration_fingerprint(base)
    after = _declaration_fingerprint(moved)
    assert before["name"] != after["name"]
    assert before["hardpoints"][first_key] != after["hardpoints"][first_key]
    for key in ("bodies", "springs", "dampers", "stops", "tires", "topology"):
        assert before[key] == after[key], key
    # The change did not write through to the declaration it was derived from.
    assert base.hardpoints[first_key] == original


# --- C36/C37/C40: the topologies and roles the file format supports ---------


def test_the_declaration_carries_the_mirrored_bodies(tmp_path: Path) -> None:
    """
    C36/C37: a document states one side and the declaration carries both.

    An axle whose body list stopped at the declared side would name half of
    itself, and the missing half would surface as "requires positive mass specs
    for upper_arm_R" rather than as a missing body.
    """
    paths = _project(tmp_path)
    entry = _suspension_entry(paths)
    declaration = axle_declaration_for(entry.subsystem, name="doc", entry=entry)
    names = {spec.name for spec in declaration.bodies}
    assert any(name.endswith("_L") for name in names)
    assert any(name.endswith("_R") for name in names)
    assert declaration.topology in {"symmetric_proxy", "explicit"}


def test_the_wheel_role_reaches_the_declaration(tmp_path: Path) -> None:
    """
    C40: the wheel subsystem's own contribution reaches the axle.

    The wheel role owns a body on an axle, so the declaration has to carry it:
    the mount it provides is what the wheel centre hangs on.
    """
    paths = _project(tmp_path)
    entry = _suspension_entry(paths)
    declaration = axle_declaration_for(entry.subsystem, name="doc", entry=entry)
    template_bodies = {
        str(row["name"]) for row in entry.subsystem.template.payload["bodies"]
    }
    declared = {spec.name for spec in declaration.bodies}
    assert template_bodies <= declared


# --- C55/C56: identity and history -----------------------------------------


def test_the_two_routes_agree_on_the_declaration_and_its_identity(
    tmp_path: Path,
) -> None:
    """
    C55: the declaration is the identity, and both origins produce one value.

    ``model_identity`` hashes a document's declaration, so two routes that
    disagreed about a hardpoint would produce two identities for one axle and the
    recorded results would stop being comparable.  The identity is therefore
    checked on the *document* the assembly is made of -- which is what it accepts
    -- while the declarations are compared field by field.
    """
    from suspension_multibody.authoring import model_identity

    paths = _project(tmp_path)
    entry = _suspension_entry(paths)
    first = axle_declaration_for(entry.subsystem, name="axle", entry=entry)
    second = axle_declaration_for(entry.subsystem, name="axle", entry=entry)
    assert _declaration_fingerprint(first) == _declaration_fingerprint(second)

    subsystem = load_subsystem(paths["subsystem"])
    assert model_identity(subsystem) == model_identity(load_subsystem(paths["subsystem"]))


def test_a_declaration_is_not_a_document_for_identity_purposes(
    tmp_path: Path,
) -> None:
    """
    C55: the identity takes documents and mappings, and refuses anything else.

    The declaration is a *value*, not a document: an identity computed from one
    would have to guess which document it came from, and guessing is what the
    identity exists to avoid.
    """
    from suspension_multibody.authoring import model_identity

    paths = _project(tmp_path)
    entry = _suspension_entry(paths)
    declaration = axle_declaration_for(entry.subsystem, name="axle", entry=entry)
    with pytest.raises(TypeError, match="model_identity takes"):
        model_identity(declaration)


def test_a_historical_result_bundle_still_reads(tmp_path: Path) -> None:
    """
    C56: reading recorded results survived the retirement.

    The result types were never model types, so retiring the two classes must not
    have touched them.  The bundle is round tripped through the loader here,
    which is the same door historical artifacts come in by.
    """
    from suspension_multibody.results import TimeSeriesResult, TimeSeriesSample
    from suspension_multibody.schema import load_dynamic_result

    result = TimeSeriesResult.from_samples(
        (
            TimeSeriesSample(time=0.0, body="axle", metrics={"heave_mm": 0.0}),
            TimeSeriesSample(time=1e-3, body="axle", metrics={"heave_mm": 1.0}),
        ),
        mode="axle_dynamic",
    )
    payload = {
        "manifest": {
            "schema_version": 1,
            "format_version": "1.0",
            "run_id": result.run_id,
            "mode": "axle_dynamic",
            "sample_count": 2,
            "provenance": {"package_version": "0.1.0"},
        },
        "samples": [
            {"time": 0.0, "body": "axle", "metrics": {"heave_mm": 0.0}},
            {"time": 1e-3, "body": "axle", "metrics": {"heave_mm": 1.0}},
        ],
        "diagnostics": [],
    }
    import json

    path = tmp_path / "bundle.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    bundle = load_dynamic_result(path)
    assert bundle.manifest.mode == "axle_dynamic"
    assert [sample.time for sample in bundle.samples] == [0.0, 1e-3]
