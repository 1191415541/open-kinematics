"""
03: the document route reaches a family by *registration*, not by a literal.

``simulate`` used to accept exactly one assembly kind and one family, spelled out
in the entry.  Adding a bench therefore meant editing that entry.  These tests
hold the two properties that replaced it:

* the pair is judged against the registries (a bench belongs to an assembly kind,
  and a family has a preparation), and
* a refusal names what was asked for and what is available, so a caller can tell
  "this bench is for another assembly" from "nobody prepared this family".

They do not claim the axle-dynamic *reading* solves: that needs the model's own
inertia and the elements the study bridge does not yet map, which is subtask 06's
work.  What is checked here is that the route reaches the family at all, and that
a document-driven run reports the same result face an object-driven one does.
"""
from __future__ import annotations

import pytest

from suspension_multibody import api
from suspension_multibody.authoring import AssemblyDocument, RigDocument
from suspension_multibody.authoring.documents import SimulationAssembly
from suspension_multibody.authoring.properties import ElementPropertyDocument
from suspension_multibody.presets import double_wishbone_subsystem
from suspension_multibody.rigs.compose import assembly_for_rig
from suspension_multibody.simulation.preparation import default_preparation_registry

HARDPOINTS = {
    "lower_front": [-120.0, -500.0, 150.0],
    "lower_rear": [120.0, -500.0, 150.0],
    "lower_outer": [0.0, -700.0, 150.0],
    "upper_front": [-100.0, -500.0, 400.0],
    "upper_rear": [100.0, -500.0, 400.0],
    "upper_outer": [0.0, -700.0, 450.0],
    "tie_inner": [100.0, -400.0, 250.0],
    "tie_outer": [50.0, -700.0, 250.0],
    "wheel_center": [0.0, -700.0, 300.0],
    "rack_center": [0.0, 0.0, 250.0],
}


def _linear(name, element_type, **parameters):
    return ElementPropertyDocument.from_payload(
        {
            "document": "element_properties",
            "schema_version": 1,
            "name": name,
            "element_type": element_type,
            "model": "linear",
            "units": {"force": "N", "length": "mm"},
            "parameters": parameters,
        }
    )


def _assembly(bench):
    subsystem = double_wishbone_subsystem(
        hardpoints=dict(HARDPOINTS),
        spring=_linear("spring", "spring", stiffness=45.0, free_length=250.0),
        damper=_linear("damper", "damper", viscous_damping=12.0),
    )
    rig = RigDocument.from_payload(
        {
            "document": "rig",
            "schema_version": 1,
            "name": "bench",
            "supported_assembly_kinds": ["suspension_axle"],
            "required_ports": [],
            "bench": bench,
            "measurements": ["wheel_travel"],
        }
    )
    document = AssemblyDocument.from_payload(
        {
            "document": "assembly",
            "schema_version": 1,
            "name": "axle",
            "assembly_kind": "suspension_axle",
            "subsystems": [
                {
                    "ref": "front.sub.json",
                    "functional_role": "suspension",
                    "placement_role": "front",
                }
            ],
            "rig": "bench",
        },
        subsystems={"front.sub.json": subsystem},
        rig=rig,
    )
    return SimulationAssembly.bind(document)


def _case(family, **extra):
    case = {
        "contract": "multibody-case",
        "contract_version": 1,
        "kind": "case",
        "family": family,
        "name": "run",
        "time": {"start_s": 0.0, "end_s": 1e-3, "step_s": 1e-3},
        "solver": {"end_time": 0.001, "step_size": 0.001},
    }
    case.update(extra)
    return case


def test_the_bench_to_assembly_pairing_is_registry_readable():
    """The pairing is a lookup, so an entry does not have to know it."""
    assert assembly_for_rig("kc_quasi_static") == "axle"
    assert assembly_for_rig("axle_dynamic") == "axle"
    assert assembly_for_rig("vehicle_kc") == "vehicle"


def test_every_axle_bench_has_a_registered_preparation():
    """A bench is reachable exactly when its family has a preparation."""
    keys = default_preparation_registry().keys()
    assert ("axle", "kc_quasi_static") in keys
    assert ("axle", "axle_dynamic") in keys


def test_the_quasi_static_bench_still_runs():
    """The registry change must not move the reading that already worked."""
    run = api.simulate(
        _assembly("kc_quasi_static"),
        _case(
            "kc_quasi_static",
            k={
                "wheel_values_mm": [0.0],
                "rack_values_mm": [],
                "drive": "wheel_center",
                "left_right_mode": "symmetric",
                "axis_map": {"wheel": ["wheel_drive_L", "wheel_drive_R"]},
            },
        ),
    )
    assert run.status == "success"
    assert run.raw is not None
    # The document route fills ``.result`` too (07): a caller that reached the run
    # through a document pair reads the same reporting bundle the object route
    # produces, rather than a successful run whose numbers are only in the raw
    # blocks.  The assembly and the reading are what the bundle needs, and the
    # entry holds both, so nothing here is re-derived.
    from suspension_multibody.schema import ResultBundle

    assert isinstance(run.result, ResultBundle)
    assert run.manifest.mode == "K"
    assert len(run.states) == 1


def test_a_bench_of_another_assembly_kind_is_refused_by_name():
    """
    A vehicle bench cannot drive an axle document, and the refusal says which is
    which -- the two vocabularies (document kind, routing name) are easy to mix.
    """
    with pytest.raises(ValueError, match="belongs to the"):
        api.simulate(_assembly("vehicle_kc"), _case("vehicle_kc"))


def test_an_unregistered_family_is_refused_by_name():
    """A family nobody prepared is refused, naming what is available."""
    with pytest.raises(ValueError, match="routes to family"):
        api.simulate(_assembly("kc_quasi_static"), _case("no_such_family"))


def test_the_document_bypass_needs_both_halves():
    """
    A case *document* beside a live model is not a fully authored request.

    It used to be treated as one, which skipped the family's preparation -- so a
    family that authors its contract from an assembled model could never be
    reached from a document case, and compilation failed on a model that was never
    a document.
    """
    from suspension_multibody.simulation.preparation import _is_document_request
    from suspension_multibody.simulation.request import SimulationRequest

    live_model = object()
    document_case = {"kind": "case"}
    assert not _is_document_request(
        SimulationRequest(
            assembly="axle",
            family="axle_dynamic",
            model=live_model,
            case=document_case,
        )
    )
    assert _is_document_request(
        SimulationRequest(
            assembly="axle",
            family="kc_quasi_static",
            model={"kind": "model"},
            case=document_case,
        )
    )


def test_the_axle_dynamic_case_document_becomes_the_family_object():
    """
    The dynamic family reads its own case vocabulary from the document.

    The reading itself is not solved here (see the module docstring); what is held
    is that the document reaches the family as the object it expects, with its
    samples on the case's own grid.
    """
    from suspension_multibody.axle_dynamics.schema import AxleDynamicsCase
    from suspension_multibody.preparation.axle_dynamic import case_from_document

    case = case_from_document(
        {
            "name": "ad",
            "time": {"start_s": 0.0, "end_s": 2e-3, "step_s": 1e-3},
            "solver": {"end_time": 0.002, "step_size": 1e-3},
            "dynamic": {"driven_target_m": {"wheel_travel_left": [0.0, 0.0, 0.0]}},
        }
    )
    assert isinstance(case, AxleDynamicsCase)
    assert case.times_s == (0.0, 1e-3, 2e-3)
    assert case.driven_target_m["wheel_travel_left"] == (0.0, 0.0, 0.0)


def test_a_dynamic_case_document_without_its_section_is_refused():
    from suspension_multibody.preparation.axle_dynamic import case_from_document

    with pytest.raises(ValueError, match="'dynamic' section"):
        case_from_document(
            {"name": "ad", "time": {"start_s": 0.0, "end_s": 1e-3, "step_s": 1e-3}}
        )


def test_a_dynamic_input_off_the_case_grid_is_refused():
    """Every sampled input is on the case's own grid, or it is refused."""
    from suspension_multibody.preparation.axle_dynamic import case_from_document

    with pytest.raises(ValueError, match="samples for a grid"):
        case_from_document(
            {
                "name": "ad",
                "time": {"start_s": 0.0, "end_s": 2e-3, "step_s": 1e-3},
                "dynamic": {"driven_target_m": {"wheel_travel_left": [0.0, 0.0]}},
            }
        )
