"""Registered benches use ordinary documents and explicit external attachments."""

from dataclasses import replace

import numpy as np
import pytest

from suspension_multibody.authoring.documents import SubsystemDocument, TemplateDocument
from suspension_multibody.authoring.generic import GenericSubsystemAssembler
from suspension_multibody.modeling.identity import EntityId
from suspension_multibody.rigs import (
    RIGS,
    build_rig_assembly,
    build_rig_fragment,
    rig_document,
    rig_subsystem_document,
    rig_template_document,
)
from suspension_multibody.subsystems.rig_link import link_wheel_supplying_rig
from suspension_multibody.subsystems.runtime import SubsystemRuntime


@pytest.mark.parametrize("name", tuple(RIGS))
def test_every_registered_bench_is_an_ordinary_template_and_subsystem(name, tmp_path):
    template = rig_template_document(name)
    subsystem = rig_subsystem_document(name)
    assert type(template) is TemplateDocument
    assert type(subsystem) is SubsystemDocument
    template.save(tmp_path / "bench.json")
    assert TemplateDocument.load(tmp_path / "bench.json").payload == template.payload
    graph = GenericSubsystemAssembler().assemble(subsystem)
    fragment = build_rig_fragment(name)
    assert set(graph.bodies) == set(fragment.bodies)
    assert graph.model_document()["tires"] == []
    assert rig_document(name).actuators == RIGS[name].coordinate_names()
    assert not fragment.tires and not fragment.forces
    if RIGS[name].supplies_wheels:
        assert len(graph.bodies) == 3
        assert {row["type"] for row in fragment.joints.values()} == {"fixed"}
    else:
        assert set(graph.bodies) == {"bench_frame"}
        assert not fragment.joints


def test_four_post_keeps_four_road_inputs_without_mechanical_platforms():
    fragment = build_rig_fragment("ride_four_post")
    assert set(fragment.bodies) == {"bench_frame"}
    assert not fragment.joints
    assert {row["coordinate"] for row in fragment.drives.values()} == {
        "road_height_fl", "road_height_fr", "road_height_rl", "road_height_rr",
    }
    assert not any(row["coordinate"].startswith("wheel_drive") for row in fragment.drives.values())
    assert build_rig_fragment("axle_dynamic").drives["motion_road_height"]["coordinate"] == "road_height"


def test_external_binding_does_not_depend_on_carrier_or_upright_names():
    bench = build_rig_assembly("kc_quasi_static")
    old = "wheel_carrier_L"
    new = "fixture"
    fragment = replace(bench.fragment, bodies={
        new if name == old else name: body for name, body in bench.fragment.bodies.items()
    })
    port = replace(bench.ports["wheel_centre_L"], owner=EntityId((), new))
    bench = replace(bench, fragment=fragment,
                    ports={**bench.ports, "wheel_centre_L": port})
    body = GenericSubsystemAssembler.materialize_bodies([{"name": "part", "mass": 1.0}])["part"]
    runtime = SubsystemRuntime("K", {"part": body}, {("part", "wheel_center"): np.zeros(3)},
                               {}, (), (), (), (), ())
    link = link_wheel_supplying_rig(runtime, bench, bindings={"wheel_centre_L": "part"})
    assert set(link.bodies) == {new}
    assert link.constraints[0].body_a == "part"
    assert link.constraints[0].body_b == new
