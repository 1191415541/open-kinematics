"""
The unified entry the axle-dynamic tests submit through.

These tests used to call ``suspension_multibody.axle_dynamics.run_axle_dynamics``.
That was a *public* entry -- one of the four scattered doors the unified entry
replaces -- and it is retired.  What it did is not retired: it compiled the
family's contract documents from the SI model and case and decoded the result
through the axle adapter.  ``run_request`` is that same submission, reached
through the same runner ``simulate`` uses, and on the same model and case it
produces bit-identical states and metrics.  Measured on the acceptance fixture,
so the migration is a substitution rather than a rewrite and no assertion is
weakened.

**Recorded deviation (08, adjudicated).**  R2=b asks for these tests to be driven
through ``simulate`` and *assembly documents*.  The shared document layer cannot
express the models they build: a template's ``functional_role`` is an enum whose
``suspension`` member must satisfy that role's ``required_mounts`` at the
vehicle's hardpoints, and ``assembly_kind`` is one of
``suspension_axle``/``full_vehicle``.  A test that builds a bare vertical slider,
a free body under a constant wrench, or a tire-drop case has no assembly document
to be written as, and the refusal is named rather than silent
(``template 'slider' does not satisfy role 'suspension': missing mount(s) [...]``).
Teaching the document layer an "arbitrary multibody system" spelling is a contract
capability the Epic's Non-Goals do not authorise, so it is recorded as the blocker
instead of being faked.  What this module *does* deliver is the part 09 needs:
after it, nothing outside ``axle_dynamics/`` calls the retired door, and the tests
that hold the physics still hold it, at the same strength.
"""
from __future__ import annotations

from dataclasses import replace
from typing import Any

from suspension_multibody.axle_dynamics.errors import NativeAxleError
from suspension_multibody.axle_dynamics.result import AxleDynamicsResult
from suspension_multibody.kernel import KernelContractError
from suspension_multibody.report.metrics import compute_case_metrics
from suspension_multibody.results.raw import RawContractResult
from suspension_multibody.simulation import SimulationRequest, run_request

__all__ = ["solve_axle"]

ASSEMBLY = "axle"
FAMILY = "axle_dynamic"


def solve_axle(model: Any, case: Any):
    """
    Submit one SI axle model and case through the unified runner.

    The returned envelope carries the ``AxleDynamicsResult`` on ``.result`` with
    its metrics, exactly as the retired entry's return value did.  A native
    failure raises the ``NativeAxleError`` the tests assert on, with the partial
    result, the failure-diagnostics row, the failed sample index, the status and
    the failed time all recovered from the partial run -- every field the old
    translation filled.
    """
    try:
        envelope = run_request(
            SimulationRequest(
                assembly=ASSEMBLY,
                family=FAMILY,
                model=model,
                case=case,
                name=getattr(case, "name", None) or FAMILY,
            )
        )
    except KernelContractError as error:
        raise _as_native_error(error, model, case) from error
    result = envelope.result
    if not isinstance(result, AxleDynamicsResult):
        raise TypeError(
            "the axle dynamic reading did not produce AxleDynamicsResult; got "
            f"{type(result).__name__}"
        )
    enriched = replace(result, metrics=compute_case_metrics(FAMILY, result))
    return replace(envelope, result=enriched)


def _as_native_error(
    error: KernelContractError, model: Any, case: Any
) -> NativeAxleError:
    """Translate a kernel refusal into the axle error the tests assert on."""
    from suspension_multibody.axle_dynamics.contract_run import (
        build_result,
        safe_failure_row,
    )

    partial = error.partial_raw_result
    if not isinstance(partial, RawContractResult):
        return NativeAxleError(str(error), status=3)
    manifest = partial.document.get("manifest", {})
    index = int(manifest.get("failed_sample_index", 0) or 0)
    status = int(manifest.get("failed_status", 3) or 3)
    partial_result = None
    try:
        decoded = build_result(model, case, partial, stop=index)
        partial_result = replace(
            decoded, metrics=compute_case_metrics(FAMILY, decoded)
        )
    except Exception:  # noqa: BLE001 - the original failure is the report
        partial_result = None
    return NativeAxleError(
        str(error),
        status=status,
        partial_result=partial_result,
        failure_diagnostics=safe_failure_row(partial, index),
        failed_sample_index=index,
        failed_time_s=float(manifest.get("failed_time_s") or 0.0),
    )
