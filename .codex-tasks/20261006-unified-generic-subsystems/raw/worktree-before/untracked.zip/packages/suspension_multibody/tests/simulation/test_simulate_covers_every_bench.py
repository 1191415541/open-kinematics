"""
07: ``simulate`` reaches every registered bench by registration, not by literal.

The entry used to answer *every* bench with an axle: it built an axle declaration
from the first suspension and asked the axle family for a reading, so a vehicle
document was refused by the axle's own rule ("a single-axle bench assembly carries
no brake or drive") and no vehicle bench was reachable at all.

What these tests hold is the route: the assembly kind decides which reading the
documents describe, the two dispatches read the same registry the refusal does,
and the result face is filled either way.  They deliberately do not claim that
every dynamic bench *converges* on the shared file fixture -- that depends on the
fixture's model data (body placement and ride elasticity), which is subtask 06's
data work and is recorded in this task's raw findings, not hidden here.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from suspension_multibody import api
from suspension_multibody.rigs.compose import assembly_for_rig
from suspension_multibody.schema import ResultBundle
from tests.authoring.fixtures import write_builtin_axle_project, write_vehicle_project

#: The seven benches the entry must reach, with the assembly kind each drives.
BENCHES: tuple[tuple[str, str], ...] = (
    ("kc_quasi_static", "axle"),
    ("axle_dynamic", "axle"),
    ("vehicle_kc", "vehicle"),
    ("vehicle_dynamic", "vehicle"),
    ("handling", "vehicle"),
    ("ride_four_post", "vehicle"),
    ("ride_random_road", "vehicle"),
)

_SOLVER: dict[str, Any] = {
    "end_time": 1e-3,
    "step_size": 1e-3,
    "internal_step_size": 1e-3,
    "min_internal_step_size": 1e-3,
    "adaptive_substepping": False,
    "integrator": "ggl_generalized_alpha",
    "gravity": [0.0, 0.0, 0.0],
}


def _bind(rig_path: Path, bench: str) -> None:
    """Bind a written rig to the bench a case is about to ask for."""
    payload = json.loads(rig_path.read_text(encoding="utf-8"))
    payload["bench"] = bench
    rig_path.write_text(json.dumps(payload), encoding="utf-8")


def _case(family: str, sections: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "contract": "multibody-case",
        "contract_version": 1,
        "kind": "case",
        "family": family,
        "name": "r",
        "time": {"start_s": 0.0, "end_s": 1e-3, "step_s": 1e-3},
        "solver": _SOLVER,
        **(sections or {}),
    }


def _axle_project(tmp_path: Path) -> dict[str, Path]:
    directory = tmp_path / "axle"
    directory.mkdir(parents=True, exist_ok=True)
    return write_builtin_axle_project(directory)


def test_every_bench_is_registered_and_owns_one_assembly() -> None:
    """The seven benches are a registry fact, which is what the dispatch reads."""
    assert tuple(name for name, _ in BENCHES) == (
        "kc_quasi_static",
        "axle_dynamic",
        "vehicle_kc",
        "vehicle_dynamic",
        "handling",
        "ride_four_post",
        "ride_random_road",
    )
    for bench, owner in BENCHES:
        assert assembly_for_rig(bench) == owner


def test_a_vehicle_document_is_not_refused_with_the_axle_rule(tmp_path: Path) -> None:
    """
    The defect 07 removes: a vehicle bench answered with an axle.

    Before the dispatch, ``simulate`` built an axle declaration from the vehicle
    document's first suspension and the axle assembly rule refused the vehicle's
    brake and drive roles -- so the refusal named the *axle's* constraint, which
    had nothing to do with what the caller asked for.
    """
    paths = write_vehicle_project(tmp_path / "vehicle")
    _bind(paths["vehicle_rig"], "vehicle_dynamic")
    run = api.simulate(paths["vehicle_assembly"], _case("vehicle_dynamic"))
    assert run.status == "success", run.raw.failure_evidence
    # The vehicle reading reports a vehicle result, not an axle one.
    from suspension_multibody.results.vehicle import VehicleDynamicsResult

    assert isinstance(run.result, VehicleDynamicsResult)
    assert run.raw is not None


def test_the_axle_result_is_filled_for_the_document_route(tmp_path: Path) -> None:
    """A K document pair yields a bundle, so the result face is not empty."""
    paths = _axle_project(tmp_path)
    _bind(paths["rig"], "kc_quasi_static")
    run = api.simulate(
        paths["assembly"],
        _case(
            "kc_quasi_static",
            {
                "k": {
                    "wheel_values_mm": [0.0, 20.0],
                    "rack_values_mm": [],
                    "drive": "wheel_center",
                    "left_right_mode": "symmetric",
                    "axis_map": {"wheel": ["wheel_drive_L", "wheel_drive_R"]},
                }
            },
        ),
    )
    assert run.status == "success", run.raw.failure_evidence
    assert isinstance(run.result, ResultBundle)
    assert len(run.states) == 2
    # The travels the document asked for are the ones the states report.
    assert run.states[1].drives["wheel_travel_right"] == pytest.approx(20.0)


def test_the_case_section_decides_which_object_a_family_is_built_with(
    tmp_path: Path,
) -> None:
    """
    A vehicle family takes its own object; the vehicle case has none of its own.

    Every vehicle bench wraps one ``VehicleDynamicCase``, and the family whose
    document *is* that case carries no section of its own.  The dispatch has to
    read the *family's* vocabulary rather than imposing one, which is what this
    asserts by building both spellings from the same assembly.
    """
    from suspension_multibody.authoring.documents import AssemblyDocument
    from suspension_multibody.authoring.vehicle import vehicle_declaration_from
    from suspension_multibody.preparation.handling import HandlingManoeuvre
    from suspension_multibody.schema.vehicle import VehicleDynamicCase

    paths = write_vehicle_project(tmp_path / "vehicle")
    declaration = vehicle_declaration_from(
        AssemblyDocument.load(paths["vehicle_assembly"])
    )
    vehicle_case = api._vehicle_case_object(
        "vehicle_dynamic", _case("vehicle_dynamic"), declaration
    )
    assert isinstance(vehicle_case, VehicleDynamicCase)
    manoeuvre = api._vehicle_case_object(
        "handling",
        _case(
            "handling",
            {"handling": {"shapes": [{"actuator": "rack", "shape": "step", "amplitude": 0.0}]}},
        ),
        declaration,
    )
    assert isinstance(manoeuvre, HandlingManoeuvre)
    assert manoeuvre.vehicle_case.vehicle is declaration


def test_a_vehicle_family_without_a_reader_is_refused_by_name() -> None:
    """A family nobody can read a case for says so instead of failing obscurely."""
    with pytest.raises(ValueError, match="no preparation module"):
        api._vehicle_case_object("no_such_family", _case("no_such_family"), object())


def test_the_bench_assembly_mismatch_is_still_refused_by_name(tmp_path: Path) -> None:
    """Registry dispatch must not weaken the bench/assembly refusal."""
    paths = _axle_project(tmp_path)
    _bind(paths["rig"], "vehicle_kc")
    # The case names the bench's own family, so the pair passes the route check and
    # the refusal being asserted is the registry's -- not the earlier mismatch.
    with pytest.raises(ValueError, match="belongs to the"):
        api.simulate(paths["assembly"], _case("vehicle_kc"))


def test_a_vehicle_document_on_an_axle_bench_is_refused_by_name(
    tmp_path: Path,
) -> None:
    """The other direction of the same rule, with the vehicle's own vocabulary."""
    paths = write_vehicle_project(tmp_path / "vehicle")
    _bind(paths["vehicle_rig"], "kc_quasi_static")
    with pytest.raises(ValueError, match="belongs to the"):
        api.simulate(paths["vehicle_assembly"], _case("kc_quasi_static"))


def test_a_dynamic_case_document_with_the_axle_vocabulary_is_refused(
    tmp_path: Path,
) -> None:
    """
    A vehicle bench and an axle case document do not describe one run.

    The reading follows from the documents, so a case written for the axle family
    cannot drive a vehicle bench; the refusal comes from the family's own reader
    naming the section it expected.
    """
    paths = write_vehicle_project(tmp_path / "vehicle")
    _bind(paths["vehicle_rig"], "handling")
    with pytest.raises(ValueError, match="'handling' section"):
        api.simulate(paths["vehicle_assembly"], _case("handling"))


def test_one_simulate_call_submits_exactly_once(tmp_path: Path, monkeypatch) -> None:
    """
    The entry compiles and submits once, and builds its result from that run.

    ``simulate`` used to be a pure pass-through with an empty result face; now it
    also decodes, and a second submission would be the easiest way to make the
    decode agree with a run that never happened.  Counting the backend calls is
    what turns "one submission" into a check rather than a reading of the source.
    """
    from suspension_multibody.simulation import backend as backend_module
    from suspension_multibody.simulation.backend import NativeContractBackend

    calls: list[object] = []
    original = NativeContractBackend.run

    def counted(self, compiled):
        calls.append(compiled)
        return original(self, compiled)

    monkeypatch.setattr(NativeContractBackend, "run", counted)
    paths = _axle_project(tmp_path)
    _bind(paths["rig"], "kc_quasi_static")
    run = api.simulate(
        paths["assembly"],
        _case(
            "kc_quasi_static",
            {
                "k": {
                    "wheel_values_mm": [0.0],
                    "rack_values_mm": [],
                    "drive": "wheel_center",
                    "left_right_mode": "symmetric",
                    "axis_map": {"wheel": ["wheel_drive_L", "wheel_drive_R"]},
                }
            },
        ),
    )
    assert run.status == "success", run.raw.failure_evidence
    assert isinstance(run.result, ResultBundle)
    assert len(calls) == 1
    assert backend_module is not None


def _in_memory_axle(paths: dict[str, Path]):
    """Build the same axle the files describe, without keeping any of them."""
    from suspension_multibody.authoring import (
        load_assembly,
        load_rig,
        load_subsystem,
        load_template,
    )
    from suspension_multibody.authoring.documents import SimulationAssembly
    from suspension_multibody.authoring.properties import ElementPropertyDocument

    directory = paths["assembly"].parent
    declaration = json.loads(paths["assembly"].read_text(encoding="utf-8"))
    templates = {
        "suspension.tpl.json": load_template(paths["template"]),
        "chassis.tpl.json": load_template(paths["chassis_template"]),
    }
    subsystems: dict[str, Any] = {}
    laws: dict[str, Any] = {}
    for row in declaration["subsystems"]:
        payload = json.loads((directory / row["ref"]).read_text(encoding="utf-8"))
        subsystems[row["ref"]] = load_subsystem(
            payload, template=templates[payload["template"]]
        )
        bound = {
            slot: ElementPropertyDocument.load(directory / name)
            for slot, name in payload["property_bindings"].items()
        }
        if bound:
            laws[row["ref"]] = bound
    return SimulationAssembly.bind(
        load_assembly(
            declaration,
            subsystems=subsystems,
            properties=laws,
            rig=load_rig(paths["rig"]),
        )
    )


def test_the_memory_route_runs_the_k_bench_with_the_project_gone(
    tmp_path: Path,
) -> None:
    """
    ``simulate`` on an assembly that was never a file, with the files deleted.

    The document route and the memory route must be one run, so the same case is
    driven through an assembly built entirely in memory and the project tree is
    removed first: nothing under it may be read once the documents exist.
    """
    import shutil

    paths = _axle_project(tmp_path)
    _bind(paths["rig"], "kc_quasi_static")
    assembly = _in_memory_axle(paths)
    shutil.rmtree(paths["assembly"].parent)

    run = api.simulate(
        assembly,
        _case(
            "kc_quasi_static",
            {
                "k": {
                    "wheel_values_mm": [0.0],
                    "rack_values_mm": [],
                    "drive": "wheel_center",
                    "left_right_mode": "symmetric",
                    "axis_map": {"wheel": ["wheel_drive_L", "wheel_drive_R"]},
                }
            },
        ),
    )
    assert run.status == "success", run.raw.failure_evidence
    assert isinstance(run.result, ResultBundle)
    assert len(run.states) == 1


def test_a_family_without_a_decoded_result_says_so_rather_than_being_silent(
    tmp_path: Path,
) -> None:
    """
    The empty result face is a *named* outcome (acceptance criterion 7).

    A vehicle K/C bench runs and succeeds, but this package defines no decoded
    domain result type for that family -- the vehicle K/C result is the raw
    contract blocks.  The envelope must say that, because a silent ``None``
    reads exactly like a decode that was skipped, and one of the two is a bug.
    The reading property is what a caller gets instead of a bare ``None``.
    """
    paths = write_vehicle_project(tmp_path / "vehicle")
    _bind(paths["vehicle_rig"], "vehicle_kc")
    run = api.simulate(
        paths["vehicle_assembly"],
        _case("vehicle_kc", {"k": {"axis_map": {}, "axes": {}}}),
    )
    assert run.status == "success", run.raw.failure_evidence
    if run.result is None:
        # Empty face: the reason is stated and the reading property refuses.
        assert run.result_reason and "no decoded domain result type" in run.result_reason
        with pytest.raises(AttributeError, match="no decoded domain result type"):
            _ = run.domain_result
    else:
        # Filled face: a reason would be a contradiction, so there must be none.
        assert run.result_reason is None
        assert run.domain_result is run.result


def test_a_run_that_decoded_carries_no_result_reason(tmp_path: Path) -> None:
    """The other half: a decoded run must not also claim an absent result."""
    paths = _axle_project(tmp_path)
    _bind(paths["rig"], "kc_quasi_static")
    run = api.simulate(
        paths["assembly"],
        _case(
            "kc_quasi_static",
            {
                "k": {
                    "wheel_values_mm": [0.0],
                    "rack_values_mm": [],
                    "drive": "wheel_center",
                    "left_right_mode": "symmetric",
                    "axis_map": {"wheel": ["wheel_drive_L", "wheel_drive_R"]},
                }
            },
        ),
    )
    assert isinstance(run.result, ResultBundle)
    assert run.result_reason is None
    assert run.domain_result is run.result
