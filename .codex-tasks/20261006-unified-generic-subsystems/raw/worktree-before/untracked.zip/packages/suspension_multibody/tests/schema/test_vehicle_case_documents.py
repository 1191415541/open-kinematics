"""
05: each vehicle bench's case object round-trips through its document.

Five vehicle benches wrap one ``VehicleDynamicCase`` and add their own inputs: a
K/C sweep, a steering manoeuvre, four pads, a random road.  ``DynamicCaseSpec`` is
not any of their contracts -- it is a different, older vocabulary -- so what these
tests hold is that each family reads *its own* section back into *its own* object,
and that the document it writes is the document it reads.

Every vehicle case wraps a ``VehicleDynamicCase``, and that wrapper needs the
vehicle it runs on.  The tests build a real declaration from a real assembly
document, which is what the document route does: the vehicle is a property of the
model, and the case states only what the bench adds.

The negative cases matter as much as the positive ones: a document with no section
for the family, and a vehicle case with no vehicle at all, are both refused, and
each refusal names what was missing.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from suspension_multibody.authoring import AssemblyDocument
from suspension_multibody.authoring.vehicle import vehicle_declaration_from
from suspension_multibody.axle_dynamics.schema import AxleSolverSettings
from suspension_multibody.cases.ride_four_post import (
    FourPostCorner,
)
from suspension_multibody.cases.ride_four_post import (
    case_document as four_post_document,
)
from suspension_multibody.cases.ride_random_road import (
    RandomRoadWheel,
    RoadComponent,
)
from suspension_multibody.cases.ride_random_road import (
    case_document as random_road_document,
)
from suspension_multibody.preparation.ride_four_post import (
    FourPostRide,
)
from suspension_multibody.preparation.ride_four_post import (
    case_from_document as four_post_from_document,
)
from suspension_multibody.preparation.ride_random_road import (
    RandomRoadRide,
)
from suspension_multibody.preparation.ride_random_road import (
    case_from_document as random_road_from_document,
)
from suspension_multibody.preparation.vehicle_case_document import (
    vehicle_case_from_document,
)

TIMES = (0.0, 1e-3, 2e-3)
SETTINGS = AxleSolverSettings()


@pytest.fixture
def declaration(tmp_path: Path):
    """Return a real vehicle declaration from a real full-vehicle document."""
    from ..authoring.fixtures import write_vehicle_project

    paths = write_vehicle_project(tmp_path)
    document = AssemblyDocument.load(paths["vehicle_assembly"])
    return vehicle_declaration_from(document)


def _document(base: dict, declaration) -> dict:
    """One family document carrying the vehicle it runs on."""
    return {**base, "vehicle_declaration": declaration}


def test_a_four_post_case_reads_its_own_corners(declaration):
    corner = FourPostCorner(
        "front_left", offset_m=0.01, amplitude_m=0.02, frequency_hz=1.5, phase_rad=0.5
    )
    document = four_post_document(
        name="four", corners=(corner,), times_s=TIMES, settings=SETTINGS
    )
    assert "four_post" in document

    ride = four_post_from_document({**document, "_declaration": declaration})
    assert isinstance(ride, FourPostRide)
    assert ride.corners == (corner,)
    assert ride.name == "four"
    assert ride.vehicle_case.solver.end_time == pytest.approx(TIMES[-1])


def test_a_four_post_document_without_its_section_is_refused(declaration):
    document = four_post_document(
        name="four",
        corners=(FourPostCorner("front_left"),),
        times_s=TIMES,
        settings=SETTINGS,
    )
    document.pop("four_post")
    with pytest.raises(ValueError, match="'four_post' section"):
        four_post_from_document({**document, "_declaration": declaration})


def test_a_four_post_document_without_corners_is_refused(declaration):
    document = four_post_document(
        name="four",
        corners=(FourPostCorner("front_left"),),
        times_s=TIMES,
        settings=SETTINGS,
    )
    document["four_post"]["corners"] = []
    with pytest.raises(ValueError, match="at least one corner"):
        four_post_from_document({**document, "_declaration": declaration})


def test_a_random_road_case_reads_its_own_profiles(declaration):
    wheel = RandomRoadWheel(
        "front_left",
        components=(
            RoadComponent(wavelength_m=5.0, amplitude_m=0.01),
            RoadComponent(wavelength_m=1.0, amplitude_m=0.002, phase_rad=1.0),
        ),
    )
    document = random_road_document(
        name="road", wheels=(wheel,), speed_mps=20.0, times_s=TIMES, settings=SETTINGS
    )
    assert "ride_random_road" in document

    ride = random_road_from_document({**document, "_declaration": declaration})
    assert isinstance(ride, RandomRoadRide)
    assert ride.speed_mps == pytest.approx(20.0)
    assert len(ride.wheels[0].components) == 2
    assert ride.vehicle_case.solver.end_time == pytest.approx(TIMES[-1])


def test_a_random_road_document_without_its_section_is_refused(declaration):
    document = random_road_document(
        name="road",
        wheels=(RandomRoadWheel("front_left", components=()),),
        speed_mps=20.0,
        times_s=TIMES,
        settings=SETTINGS,
    )
    document.pop("ride_random_road")
    with pytest.raises(ValueError, match="'ride_random_road' section"):
        random_road_from_document({**document, "_declaration": declaration})


def test_a_vehicle_case_without_a_vehicle_is_refused():
    """
    A vehicle case with no vehicle is not a run.

    The declaration comes from the assembly the case belongs to; a caller that has
    neither is refused, and the refusal says which spelling was expected.
    """
    with pytest.raises(ValueError, match="'vehicle' block"):
        vehicle_case_from_document(
            {
                "name": "no-vehicle",
                "time": {"start_s": 0.0, "end_s": 1e-3, "step_s": 1e-3},
                "solver": {"end_time": 0.001, "step_size": 0.001},
            },
            times_s=(0.0, 1e-3),
        )


def test_the_vehicle_case_carries_the_window_the_document_states(declaration):
    """
    The window is stated once, in the document's time block.

    A vehicle case integrates a window rather than reporting a sample list, so the
    window lives on its solver; reading it from ``time`` is what keeps a document
    from having to spell the same two numbers twice.
    """
    case = vehicle_case_from_document(
        {
            "name": "grid",
            "time": {"start_s": 0.0, "end_s": 2e-3, "step_s": 1e-3},
            "solver": {},
        },
        times_s=(0.0, 1e-3, 2e-3),
        declaration=declaration,
    )
    assert case.solver.end_time == pytest.approx(2e-3)
    assert case.solver.step_size == pytest.approx(1e-3)
    assert case.name == "grid"


def test_a_family_document_does_not_ask_for_a_trim_the_case_never_declared(
    declaration,
):
    """
    The family's solver block keeps the case's own initialisation.

    A family's case document carries one ``solver`` block, and two readers look
    at it: the family's own reader (``settings``) and the vehicle-case reader
    (``static_equilibrium``).  The family reader used to fall back to
    ``AxleSolverSettings()``'s own default, which is ``static_equilibrium`` --
    so a case that declared no trim was handed one anyway, and the four dynamic
    benches stopped at ``static equilibrium initialization failed`` on models
    whose state the caller had provided.  The two spellings now mean one thing.
    """
    document = four_post_document(
        name="no-trim",
        corners=(FourPostCorner("front_left"),),
        times_s=TIMES,
        settings=AxleSolverSettings(initialization_mode="provided_consistent_state"),
    )
    ride = four_post_from_document({**document, "_declaration": declaration})
    assert ride.settings.initialization_mode == "provided_consistent_state"

    # The same document without the field: the vehicle case says nothing about a
    # trim, so neither does the family's solver block.
    document["solver"].pop("initialization_mode", None)
    ride = four_post_from_document({**document, "_declaration": declaration})
    assert ride.settings.initialization_mode == "provided_consistent_state"

    # A case that *does* ask for one still gets it, under either spelling.
    document["vehicle_dynamic"] = {"static_equilibrium": True}
    ride = four_post_from_document({**document, "_declaration": declaration})
    assert ride.settings.initialization_mode == "static_equilibrium"


def test_a_non_positive_step_is_refused():
    """The grid is a rule; a step that cannot produce samples is refused."""
    from suspension_multibody.preparation.case_documents import grid_times

    with pytest.raises(ValueError, match="step_s must be positive"):
        grid_times({"time": {"start_s": 0.0, "end_s": 1.0, "step_s": 0.0}})


def test_each_family_states_its_inputs_in_its_own_section(declaration):
    """
    The vocabulary is the family's, so a section for another family is not read.

    A four-post document given to the random-road reader names the section the
    random-road reader wanted, rather than silently finding nothing to drive.
    """
    document = four_post_document(
        name="four",
        corners=(FourPostCorner("front_left"),),
        times_s=TIMES,
        settings=SETTINGS,
    )
    with pytest.raises(ValueError, match="'ride_random_road' section"):
        random_road_from_document({**document, "_declaration": declaration})
