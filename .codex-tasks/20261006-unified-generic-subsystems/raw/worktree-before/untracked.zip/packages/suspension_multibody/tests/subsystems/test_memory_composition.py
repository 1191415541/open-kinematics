"""
The in-memory route and the file route assemble the same model.

A model can now be described twice: as files under a project directory, or as
the same declarations held in memory.  If those two routes produce different
runtimes, then "the object is the file" is a claim and not a fact, and every
later guarantee -- that an optimisation loop needs no disk, that a saved model
reloads to the same physics -- rests on nothing.

These tests therefore never assert "an assembly was built".  They build both
routes from one declaration and compare the runtimes entity by entity, which is
the only comparison that can catch a silent divergence.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from suspension_multibody.authoring import (
    AuthoringError,
    load_assembly,
    load_rig,
    load_subsystem,
    load_template,
)
from suspension_multibody.authoring.documents import (
    AssemblyDocument,
    RigDocument,
)
from suspension_multibody.authoring.properties import ElementPropertyDocument
from suspension_multibody.authoring.solver import (
    assembly_request_for,
)
from suspension_multibody.preparation.kc_quasi_static import assembly_for
from suspension_multibody.templates.builtin import DOUBLE_WISHBONE
from tests.authoring.fixtures import write_axle_project


def _fingerprint(runtime: object) -> dict[str, object]:
    """Describe a runtime by the entities and values a solve would read."""

    def names(items: object) -> list[str]:
        out: list[str] = []
        for item in items or ():
            out.append(str(getattr(item, "name", item)))
        return sorted(out)

    return {
        "bodies": names(getattr(runtime, "bodies", ())),
        "points": sorted(str(name) for name in (getattr(runtime, "points", {}) or {})),
        "constraints": names(getattr(runtime, "constraints", ())),
        "elements": names(getattr(runtime, "elements", ())),
        "connections": names(getattr(runtime, "connections", ())),
    }


def test_the_file_and_memory_routes_reach_the_same_runtime(tmp_path: Path) -> None:
    """
    One declaration, two routes, one runtime.

    The file route is the one the repository already trusts; the memory route is
    built from the very payloads those files contain, so any difference is the
    memory route losing or inventing something on the way in.
    """
    written = write_axle_project(tmp_path)
    from_file = assembly_for(
        _model_from_files(written), mode="K", rig="kc_quasi_static"
    )

    documents = _documents_from_files(written)
    in_memory = assembly_for(
        _model_from_documents(documents, mode="K"), mode="K", rig="kc_quasi_static"
    )

    assert _fingerprint(in_memory) == _fingerprint(from_file)


def _documents_from_files(written: dict[str, Path]) -> dict[str, object]:
    """Read the project's files into the in-memory documents."""
    template = load_template(written["template"])
    spring = ElementPropertyDocument.load(written["spring"])
    subsystem = load_subsystem(
        json.loads(written["subsystem"].read_text(encoding="utf-8")),
        template=template,
    )
    chassis_template = load_template(written["chassis_template"])
    chassis = load_subsystem(
        json.loads(written["chassis_subsystem"].read_text(encoding="utf-8")),
        template=chassis_template,
    )
    rig = load_rig(written["rig"])
    assembly = load_assembly(
        json.loads(written["assembly"].read_text(encoding="utf-8")),
        subsystems={
            "front.sub.json": subsystem,
            "chassis.sub.json": chassis,
        },
        properties={"front.sub.json": {"spring": spring}},
        rig=rig,
    )
    return {"assembly": assembly, "rig": rig}


def _model_from_files(written: dict[str, Path]) -> object:
    """Build the axle model through the file route the repository already uses."""
    from suspension_multibody.authoring.solver import axle_declaration_for

    assembly = AssemblyDocument.load(written["assembly"])
    suspensions = [
        entry for entry in assembly.entries if entry.functional_role == "suspension"
    ]
    return axle_declaration_for(
        suspensions[0].subsystem, name="front_axle", entry=suspensions[0]
    )


def _model_from_documents(documents: dict[str, object], *, mode: str) -> object:
    """Build the axle model through the in-memory documents."""
    from suspension_multibody.authoring.solver import axle_declaration_for

    assembly = documents["assembly"]
    assert isinstance(assembly, AssemblyDocument)
    suspensions = [
        entry for entry in assembly.entries if entry.functional_role == "suspension"
    ]
    return axle_declaration_for(
        suspensions[0].subsystem, name="front_axle", entry=suspensions[0]
    )


def test_the_memory_assembly_carries_every_role_the_file_does(
    tmp_path: Path,
) -> None:
    written = write_axle_project(tmp_path)
    from_file = AssemblyDocument.load(written["assembly"])
    documents = _documents_from_files(written)
    in_memory = documents["assembly"]
    assert isinstance(in_memory, AssemblyDocument)

    assert [e.ref for e in in_memory.entries] == [e.ref for e in from_file.entries]
    assert [(e.functional_role, e.placement_role) for e in in_memory.entries] == [
        (e.functional_role, e.placement_role) for e in from_file.entries
    ]
    assert in_memory.wheel_ends() == from_file.wheel_ends()
    assert in_memory.role_counts() == from_file.role_counts()


def test_the_memory_route_refuses_a_rig_it_cannot_satisfy(tmp_path: Path) -> None:
    """
    A bad bind fails in memory as it fails from files.

    The rig is resolved the same way on both routes, so a rig that wants a port
    the assembly does not offer must be refused by name rather than assembled
    around.
    """
    written = write_axle_project(tmp_path)
    spring = ElementPropertyDocument.load(written["spring"])
    documents = _documents_from_files(written)
    assembly = documents["assembly"]
    assert isinstance(assembly, AssemblyDocument)

    rigid = RigDocument.from_payload(
        {
            "document": "rig",
            "schema_version": 1,
            "name": "strict_bench",
            "supported_assembly_kinds": ["suspension_axle"],
            "required_ports": ["port_that_does_not_exist"],
        }
    )
    rebuilt = AssemblyDocument.from_payload(
        assembly.to_payload(),
        subsystems={e.ref: e.subsystem for e in assembly.entries},
        properties={"front.sub.json": {"spring": spring}},
        rig=rigid,
    )
    with pytest.raises(AuthoringError) as failure:
        from suspension_multibody.authoring.documents import SimulationAssembly

        SimulationAssembly.bind(rebuilt)
    assert "port_that_does_not_exist" in str(failure.value)


def test_an_in_memory_assembly_reaches_the_composition_request(tmp_path: Path) -> None:
    """
    The request the composition consumes is the same one the file produced.

    This is the join between the document layer and the assembly layer: if the
    memory route reached a different request, the runtimes could still agree by
    accident while the two routes disagreed about the roles.
    """
    written = write_axle_project(tmp_path)
    documents = _documents_from_files(written)
    assembly = documents["assembly"]
    assert isinstance(assembly, AssemblyDocument)

    from_request = assembly_request_for(AssemblyDocument.load(written["assembly"]), mode="K")
    memory_request = assembly_request_for(assembly, mode="K")

    assert memory_request.mode == from_request.mode
    assert memory_request.subsystems == from_request.subsystems
    assert memory_request.suspension_template is not None
    assert from_request.suspension_template is not None


def test_a_builtin_exported_to_memory_still_composes(tmp_path: Path) -> None:
    """
    A registered built-in, exported and rebuilt in memory, still assembles.

    The export already existed; this pins that the *in-memory* rebuild of it is
    accepted by the same composition, so a template built from a payload is a
    usable template and not merely a loadable one.
    """
    from suspension_multibody.authoring.solver import (
        runtime_template_from,
        template_document_from,
    )

    payload = template_document_from(DOUBLE_WISHBONE)
    document = load_template(payload)
    assert document.path is None
    runtime = runtime_template_from(document)
    assert runtime.name == DOUBLE_WISHBONE.name
    assert len(runtime.parts) == len(DOUBLE_WISHBONE.parts)
    assert [p.name for p in runtime.parts] == [p.name for p in DOUBLE_WISHBONE.parts]


def test_the_memory_route_needs_no_project_directory(tmp_path: Path) -> None:
    """
    The memory route reads no file under the project directory.

    The declarations come from the files once, and then the directory is removed;
    what remains must still assemble, because that is the difference the whole
    object route exists to make.
    """
    written = write_axle_project(tmp_path)
    documents = _documents_from_files(written)
    for path in written.values():
        path.unlink()
    runtime = assembly_for(
        _model_from_documents(documents, mode="K"), mode="K", rig="kc_quasi_static"
    )
    assert runtime.bodies is not None
