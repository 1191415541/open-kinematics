"""
The composition reads axle *facts*, not a particular model class.

The assembly layer used to name ``AxleDeclaration`` in its signatures, which made
that concrete class the only legal input to an axle assembly.  The thing it
actually reads is a set of fields -- hardpoints, bodies, elements, topology -- so
the protocol that replaced the class is only worth having if a *different*
supplier satisfies it and assembles correctly.

These tests provide exactly that: a stand-in that is not a ``AxleDeclaration``,
carries the same facts, and reaches the same runtime.  If the decoupling had
merely been a rename of the annotation, this module would fail to even import,
let alone assemble.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from suspension_multibody.schema import (
    BumpStop,
    IdealJointSpec,
    LinearSpring,
    RigidBodySpec,
    StaticDamper,
    Vec3,
)
from suspension_multibody.schema.model import AxleDeclaration
from suspension_multibody.subsystems.si_assembly import axle_contributions_and_order
from suspension_multibody.subsystems.types import (
    AssemblyRequest,
    AxleInput,
    VehicleInput,
)
from tests.authoring.fixtures import COORDINATES


@dataclass
class StandInAxle:
    """
    An axle model that is *not* a AxleDeclaration.

    It carries only the fields the composition reads.  It deliberately does not
    subclass the legacy model, and it is not a pydantic model: the point is that
    the protocol is structural, so any object with these attributes is accepted.
    """

    name: str = "stand_in_axle"
    hardpoints: dict[str, Vec3] = field(default_factory=dict)
    bodies: tuple[RigidBodySpec, ...] = ()
    joints: tuple[IdealJointSpec, ...] = ()
    topology: str = "symmetric_proxy"
    units: Any = None
    road: Any = None
    springs: tuple[LinearSpring, ...] = ()
    dampers: tuple[StaticDamper, ...] = ()
    stops: tuple[BumpStop, ...] = ()
    bushings: tuple[Any, ...] = ()
    anti_roll_bars: tuple[Any, ...] = ()
    tires: tuple[Any, ...] = ()
    rack_fixed_to_chassis: bool = False
    rack_axis: Vec3 = field(default_factory=lambda: Vec3(x=0.0, y=1.0, z=0.0))

    def model_dump(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        """Return the declaration; the one method the axle path calls."""
        return {"name": self.name}


def _hardpoints() -> dict[str, Vec3]:
    """
    Return the fixture coordinates under the names the composition looks up.

    The alias table resolves a role through its *uppercase* spellings, so the
    keys here are the fixture's roles upper-cased -- which is the same spelling
    the file route's own adapter emits, and therefore the same lookup the real
    model goes through.
    """
    # The names are the alias table's *canonical* spellings, not the fixture's
    # role keys: the lookup normalises to uppercase and then matches the table's
    # own list, and `tie_inner` is listed as TIE_ROD_INNER rather than TIE_INNER.
    aliases = {
        "tie_inner": "TIE_ROD_INNER",
        "tie_outer": "TIE_ROD_OUTER",
        "rack_center": "RACK_CENTER",
        "wheel_center": "WHEEL_CENTER",
    }
    return {
        aliases.get(name, name.upper()): Vec3(x=point[0], y=point[1], z=point[2])
        for name, point in COORDINATES.items()
    }


def test_the_stand_in_satisfies_the_protocol_structurally() -> None:
    """
    The protocol is structural, not nominal.

    ``runtime_checkable`` protocols answer ``isinstance`` by looking for the
    attributes, which is what lets a foreign supplier in without inheriting from
    anything.
    """
    stand_in = StandInAxle(hardpoints=_hardpoints())
    assert isinstance(stand_in, AxleInput)


def test_the_declaration_still_satisfies_the_protocol() -> None:
    """The declaration is one satisfier of the protocol, not its definition."""
    from suspension_multibody.schema.model import MassSpec

    declaration = AxleDeclaration(
        hardpoints=_hardpoints(),
        bodies=(RigidBodySpec(name="upper_arm_L", mass=12.0),),
        mass=MassSpec(sprung_mass=600.0),
    )
    assert isinstance(declaration, AxleInput)


def test_a_stand_in_axle_reaches_the_composition() -> None:
    """
    The stand-in composes, so the composition never needed the class itself.

    Asserting that a runtime was produced would be weak; what is asserted is the
    contribution set, which is what the composition actually derives from the
    model it was handed.
    """
    stand_in = StandInAxle(hardpoints=_hardpoints())
    contributions, order = axle_contributions_and_order(
        stand_in, request=AssemblyRequest(mode="K")
    )
    assert contributions  # the suspension contributed something
    roles = {contribution.role for contribution in contributions}
    assert "suspension" in roles


def test_the_composition_does_not_import_the_declaration_type() -> None:
    """
    The decoupling is real, and this is the check that keeps it that way.

    A comment claiming a module does not depend on a class survives a refactor
    that reintroduces the dependency; a source check does not.
    """
    import inspect

    from suspension_multibody.subsystems import assembler, entry, explicit, si_assembly

    for module in (si_assembly, explicit, assembler, entry):
        source = inspect.getsource(module)
        # Docstrings may *mention* it; an import or an annotation may not.
        for line in source.splitlines():
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith('"'):
                continue
            assert "AxleDeclaration" not in stripped or "``" in stripped, (
                f"{module.__name__} still names AxleDeclaration in code: {stripped!r}"
            )


class StandInVehicle:
    """
    A vehicle that is not a ``VehicleDeclaration``.

    The vehicle path reads far fewer fields than the axle one -- the chassis, the
    driveline and the wheels -- so a description from documents only has to carry
    those three to be assembled by the same code.
    """

    name = "stand_in_vehicle"
    chassis: Any = None
    wheels: tuple[Any, ...] = ()
    driveline: Any = None
    units: Any = None
    coordinate_system: Any = None
    steering: Any = None
    steering_channels: Any = ()
    coordinate_couplers: Any = ()
    aerodynamic_drag: Any = None
    front_axle: Any = None
    rear_axle: Any = None

    def model_dump(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        """Return the declaration; the one method the vehicle path calls."""
        return {}


def test_a_stand_in_vehicle_satisfies_the_vehicle_protocol() -> None:
    assert isinstance(StandInVehicle(), VehicleInput)


def test_the_vehicle_declaration_satisfies_the_vehicle_protocol() -> None:
    from suspension_multibody.schema.vehicle import VehicleDeclaration

    assert all(
        member in VehicleDeclaration.model_fields
        for member in ("name", "chassis", "wheels", "driveline", "front_axle", "rear_axle")
    )


def test_the_vehicle_path_does_not_import_the_declaration_type() -> None:
    """The vehicle-side decoupling, kept honest by a source check."""
    import inspect

    from suspension_multibody.subsystems import torque_elements, vehicle_assembly

    for module in (vehicle_assembly, torque_elements):
        for line in inspect.getsource(module).splitlines():
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith('"'):
                continue
            assert "VehicleDeclaration" not in stripped or "``" in stripped or "class" in stripped, (
                f"{module.__name__} still names VehicleDeclaration in code: {stripped!r}"
            )
