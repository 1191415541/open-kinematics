"""Capture the pre-migration checkout and gate the unified model cutover."""

from __future__ import annotations

import argparse
import ast
import hashlib
import inspect
import json
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
PACKAGE = ROOT / "packages/suspension_multibody"
EPIC = ROOT / ".codex-tasks/20261006-unified-generic-subsystems"
PREVIOUS = ROOT / ".codex-tasks/20261006-generic-multibody-evolution/raw"
TARGETS = {
    "simulate", "simulate_generic", "compile_generic", "assemble_generic",
    "GenericSubsystemAssembler", "assembly_for", "si_assembly_for_axle",
    "axle_declaration_for", "vehicle_declaration_from", "adapt_legacy_prepared_request",
    "link_wheel_supplying_rig", "merge_rig_link", "model_view", "element_rows",
    "run_request", "run_plan", "compile_request", "compile_plan", "compile_documents",
    "run_compiled", "decoder_for", "decode_result", "decode_axle_result",
    "decode_vehicle_result", "kc_case_run", "prepare_request",
}


def digest(data: bytes) -> str:
    """Return the content identity used throughout the evidence."""
    return hashlib.sha256(data).hexdigest()


def git(*arguments: str) -> bytes:
    """Read Git state without touching the index or checkout."""
    return subprocess.run(
        ["git", "-c", "core.quotepath=false", *arguments], cwd=ROOT,
        capture_output=True, check=True,
    ).stdout


def location(symbol: Any) -> dict[str, Any]:
    """Locate one runtime registration in the actual checkout."""
    filename = inspect.getsourcefile(symbol)
    if filename is None:
        raise ValueError(f"no source for {symbol!r}")
    return {
        "file": Path(filename).relative_to(ROOT).as_posix(),
        "line": inspect.getsourcelines(symbol)[1],
        "symbol": f"{symbol.__module__}.{symbol.__qualname__}",
    }


def registrations() -> dict[str, Any]:
    """Enumerate live registries; do not infer support from family names."""
    from suspension_multibody.compilation.compile import default_emitters
    from suspension_multibody.results.decoder import decode_result
    from suspension_multibody.rigs.compose import combinations
    from suspension_multibody.rigs.rig import RIGS
    from suspension_multibody.simulation.dispatch import default_registry
    from suspension_multibody.simulation.preparation import default_preparation_registry
    from suspension_multibody.studies.study import STUDIES

    preparations = default_preparation_registry()
    compilers = default_registry()
    emitters = default_emitters()
    prepared = []
    for assembly, family in preparations.keys():
        entry = preparations.resolve(assembly, family)
        prepared.append({
            "assembly": assembly, "family": family,
            "entry": f"{entry.module}.{entry.function}",
            "registration": location(default_preparation_registry),
            "build": f"preparation.{family}.prepare_request",
            "submit": "simulation.runner.run_compiled",
            "decode": "results.decoder.decode_result",
            "target": "ResolvedModel -> unified compiler -> ResultEnvelope",
        })
    return {
        "preparations": prepared,
        "compilers": [
            {"key": list(key), **location(type(compilers.resolve(*key)))}
            for key in compilers.keys()
        ],
        "emitters": [
            {"key": key, **location(type(emitters.resolve(key)))}
            for key in emitters.keys()
        ],
        "rigs": [
            {"key": key, "study": value.study, "supplies_wheels": value.supplies_wheels,
             "route": value.route, "drives": list(value.coordinate_names())}
            for key, value in RIGS.items()
        ],
        "combinations": [list(key) for key in combinations()],
        "studies": [
            {"key": key, "time_semantics": value.time_semantics,
             "tire_activation": value.tire_activation}
            for key, value in STUDIES.items()
        ],
        "decoder": location(decode_result),
        "generic": {
            "entry": "authoring.generic.simulate_generic",
            "compiler": "authoring.generic.compile_generic",
            "families": ["axle_dynamic", "kc_quasi_static"],
            "registered_with_automotive": False,
        },
        "comparison": {"entry": "cases.comparison", "kind": "independent comparison"},
    }


def consumers() -> list[dict[str, Any]]:
    """Record calls, imports and text consumers with exact source locations."""
    result: list[dict[str, Any]] = []
    for base in (PACKAGE / "src", PACKAGE / "scripts", PACKAGE / "tests", ROOT / "scripts", ROOT / "examples"):
        if not base.exists():
            continue
        for path in sorted(base.rglob("*.py")):
            if "__pycache__" in path.parts:
                continue
            tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
            relative = path.relative_to(ROOT).as_posix()
            category = "test" if "/tests/" in relative else "production"
            if "/adams/" in relative:
                category = "adams"
            elif "/report/" in relative:
                category = "report"
            elif relative.startswith("examples/"):
                category = "example"
            for node in ast.walk(tree):
                symbols: list[str] = []
                if isinstance(node, ast.Call):
                    func = node.func
                    name = func.id if isinstance(func, ast.Name) else func.attr if isinstance(func, ast.Attribute) else ""
                    if name in TARGETS:
                        symbols.append(ast.unparse(func))
                elif isinstance(node, ast.ImportFrom):
                    symbols.extend(
                        f"{node.module}.{alias.name}" for alias in node.names
                        if alias.name in TARGETS or any(
                            part in (node.module or "") for part in ("si_assembly", "rig_link", "presets.legacy", "model_view")
                        )
                    )
                if symbols:
                    result.append({
                        "file": relative, "line": node.lineno, "kind": type(node).__name__,
                        "symbols": symbols, "category": category,
                        "target": "unified document/resolver/compiler/measurement",
                    })
    for path in sorted((PACKAGE / "docs").rglob("*.md")):
        for line, text in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
            matched = sorted(name for name in TARGETS if name in text)
            if matched:
                result.append({"file": path.relative_to(ROOT).as_posix(), "line": line,
                               "symbols": matched, "category": "documentation", "kind": "text"})
    tests = [row for row in result if row["category"] == "test"]
    for row in result:
        names = {str(value).rsplit(".", 1)[-1] for value in row["symbols"]}
        row["tests"] = sorted({
            test["file"] for test in tests
            if names.intersection(str(value).rsplit(".", 1)[-1] for value in test["symbols"])
        })
    return result


def snapshot(directory: Path) -> dict[str, Any]:
    """Preserve complete patches and non-ignored untracked file contents."""
    directory.mkdir(parents=True, exist_ok=True)
    metadata: dict[str, Any] = {}
    commands = {
        "head": ("rev-parse", "HEAD"), "branch": ("branch", "--show-current"),
        "status": ("status", "--porcelain=v1", "-z"),
        "staged": ("diff", "--cached", "--binary", "--full-index"),
        "unstaged": ("diff", "--binary", "--full-index"),
    }
    for name, arguments in commands.items():
        content = git(*arguments)
        (directory / f"{name}.txt").write_bytes(content)
        metadata[name] = {"sha256": digest(content), "bytes": len(content)}
    untracked = git("ls-files", "--others", "--exclude-standard", "-z")
    files = [ROOT / name.decode("utf-8") for name in untracked.split(b"\0") if name]
    with zipfile.ZipFile(directory / "untracked.zip", "w", compression=zipfile.ZIP_DEFLATED) as archive:
        metadata["untracked"] = []
        for path in files:
            content = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            archive.writestr(relative, content)
            metadata["untracked"].append({"file": relative, "sha256": digest(content)})
    return metadata


def fingerprints() -> dict[str, str]:
    """Fingerprint source and every frozen data file, without rewriting it."""
    result: dict[str, str] = {}
    for package in ("suspension_multibody", "suspension_kernel", "suspension_contracts"):
        for component in ("src", "cpp", "scripts"):
            base = ROOT / "packages" / package / component
            if not base.exists():
                continue
            for path in sorted(base.rglob("*")):
                if path.is_file() and path.suffix in {".py", ".json", ".hpp", ".cpp", ".h", ".c"} and "__pycache__" not in path.parts:
                    result[path.relative_to(ROOT).as_posix()] = digest(path.read_bytes())
    return result


def compiled_examples(directory: Path) -> list[dict[str, Any]]:
    """Save actual pre-migration native documents; this does not run a solver."""
    from suspension_multibody.authoring.documents import AssemblyDocument
    from suspension_multibody.authoring.generic import compile_generic

    result = []
    directory.mkdir(parents=True, exist_ok=True)
    for path in sorted((ROOT / "examples/generic_multibody").glob("*.assembly.json")):
        document = AssemblyDocument.load(path)
        case = {
            "contract": "multibody-case", "contract_version": 1, "kind": "case",
            "family": "axle_dynamic", "name": "inventory",
            "time": {"start_s": 0.0, "end_s": 0.001, "step_s": 0.001},
            "solver": {"end_time": 0.001, "step_size": 0.001},
        }
        compiled = compile_generic(document, case)
        payload = compiled.model_payload
        filename = f"{path.stem}.container"
        (directory / filename).write_bytes(payload)
        result.append({"input": path.relative_to(ROOT).as_posix(),
                       "model_sha256": digest(payload), "case": case,
                       "artifact": str(directory / filename)})
    if not result:
        raise ValueError("no current generic compiled examples captured")
    return result


def capture(output: Path) -> None:
    """Capture a recoverable inventory and report incomplete reads as failures."""
    evidence: dict[str, Any] = {
        "schema_version": 1, "producer": str(Path(__file__).relative_to(ROOT)),
        "captured_at": datetime.now(timezone.utc).isoformat(), "snapshot_complete": False,
        "errors": [],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        evidence["git"] = snapshot(output.parent / "worktree-before")
        source = fingerprints()
        evidence["source_fingerprints"] = source
        evidence["production_fingerprint"] = digest(json.dumps(source, sort_keys=True).encode())
        evidence["registrations"] = registrations()
        evidence["consumers"] = consumers()
        old = json.loads((PREVIOUS / "baseline-fingerprints.json").read_text(encoding="utf-8"))
        frozen = {}
        for filename, expected in old.items():
            path = ROOT / filename.replace("\\", "/")
            actual = digest(path.read_bytes())
            if actual != expected:
                raise ValueError(f"previous frozen file changed: {filename}")
            frozen[path.relative_to(ROOT).as_posix()] = actual
        for path in (PACKAGE / "tests/data").rglob("*.json"):
            if "baseline" in path.as_posix():
                frozen[path.relative_to(ROOT).as_posix()] = digest(path.read_bytes())
        evidence["frozen_fingerprints"] = frozen
        evidence["known_failures"] = (PREVIOUS / "baseline-failures.md").read_text(encoding="utf-8")
        evidence["compiled_examples"] = compiled_examples(output.parent / "compiled-before")
        evidence["snapshot_complete"] = True
    except Exception as error:
        evidence["errors"].append(f"{type(error).__name__}: {error}")
        raise
    finally:
        output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"PASS inventory: {len(evidence['consumers'])} references, "
          f"{len(evidence['frozen_fingerprints'])} frozen files; {output}")


def cutover(inventory: Path) -> None:
    """Require a complete consumer mapping before any production retirement."""
    evidence = json.loads(inventory.read_text(encoding="utf-8"))
    if not evidence.get("snapshot_complete"):
        raise ValueError("migration inventory is incomplete")
    for filename, expected in evidence["frozen_fingerprints"].items():
        if digest((ROOT / filename).read_bytes()) != expected:
            raise ValueError(f"frozen file changed: {filename}")
    mapping = json.loads((inventory.parent / "migration-consumers.json").read_text(encoding="utf-8"))
    expected = {(row["file"], row["line"]) for row in evidence["consumers"] if row["category"] != "test"}
    actual = {(row["file"], row["line"]) for row in mapping["consumers"] if row["validated"] and row["target"]}
    if expected - actual:
        raise ValueError(f"unmapped consumers: {sorted(expected - actual)}")
    commands = [
        [sys.executable, str(EPIC / "planning/checks.py"), "numeric"],
        [sys.executable, str(EPIC / "planning/checks.py"), "structural"],
        ["uv", "run", "--no-sync", "pytest",
         "packages/suspension_multibody/tests/simulation/test_single_model_pipeline.py",
         "packages/suspension_multibody/tests/physics/test_wheel_spin_boundary.py",
         "packages/suspension_multibody/tests/architecture/test_unified_model_cutover.py",
         "-q", "-p", "no:cacheprovider"],
    ]
    for command in commands:
        subprocess.run(command, cwd=ROOT, check=True)
    print("PASS: all inventoried consumers and live cutover gates")


def main() -> None:
    """Run capture or the explicit pre-delete gate."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--inventory", nargs="?", const="capture")
    parser.add_argument("--output", type=Path, default=EPIC / "raw/inventory.json")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.check:
        if args.inventory in (None, "capture"):
            parser.error("--check requires --inventory PATH")
        cutover(Path(args.inventory))
    elif args.inventory == "capture":
        if args.output.exists():
            parser.error("inventory already exists; retain the original capture")
        capture(args.output)
    else:
        parser.error("use --inventory or --check --inventory PATH")


if __name__ == "__main__":
    main()
